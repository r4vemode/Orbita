import test from 'node:test';
import assert from 'node:assert/strict';
import https from 'node:https';
import {EventEmitter} from 'node:events';
import {createProviderRegistry,createEndpointProvider,parseProviderResponse,safeHttpGet} from '../lib/radar/providers/index.mjs';
import {createPipeline} from '../lib/radar/pipeline.mjs';
import {publicIp,safeSourceUrl} from '../lib/radar/model.mjs';
test('Radar provider registry isolates configuration and enables official feeds on a public production deployment',()=>{
 assert.equal(createProviderRegistry({env:{}}).some(provider=>provider.enabled),false);
 const production={NODE_ENV:'production',ORBITA_PUBLIC_ORIGIN:'https://orbita.example.test'};
 const official=['official-yandex','official-x5','official-polyus','official-lukoil','official-novatek','official-scf',
  'official-mmk','official-rusal','official-phosagro','official-seligdar','official-t-technologies','official-mts','official-vk','official-headhunter','official-rostelecom'];
 assert.deepEqual(createProviderRegistry({env:production}).filter(provider=>provider.enabled).map(provider=>provider.id),official);
 assert.equal(createProviderRegistry({env:{...production,RADAR_PROVIDER_MODE:'off'}}).some(provider=>provider.enabled),false);
 const mocks=createProviderRegistry({env:{RADAR_PROVIDER_MODE:'mock'}});assert.deepEqual(mocks.filter(provider=>provider.enabled).map(provider=>provider.id),['mock']);
 const live=createProviderRegistry({env:{RADAR_PROVIDER_MODE:'live',RADAR_EDISCLOSURE_ENABLED:'true',RADAR_EDISCLOSURE_ENDPOINT:'https://feed.moex.com/events'}});assert.deepEqual(live.filter(provider=>provider.enabled).map(provider=>provider.id),[...official,'edisclosure']);assert.equal(live.find(provider=>provider.id==='edisclosure').interval,5000);
 assert.throws(()=>createProviderRegistry({env:{RADAR_PROVIDER_MODE:'all'}}));assert.throws(()=>createProviderRegistry({env:{RADAR_IR_ENABLED:'yes'}}));assert.throws(()=>createProviderRegistry({env:{RADAR_IR_INTERVAL:'10'}}));
});
test('Radar JSON adapter normalizes provider identity, bounds cursor and avoids returning configuration credentials',async()=>{
 let request;const provider=createEndpointProvider({id:'edisclosure',name:'Disclosure',sourceType:'DISCLOSURE',endpoint:'https://feed.moex.com/events',apiKey:'unit-private-key',enabled:true,requestImpl:async(url,options)=>{request={url,options};return {contentType:'application/json',body:JSON.stringify({events:[{externalId:'event1',sourceUrl:'https://www.moex.com/news/1',publishedAt:'2026-10-30T10:00:00Z',title:'Сбер',rawText:'Решение',provider:'spoof'}],cursor:'next-1'})};}});
 const result=await provider.fetchEvents({cursor:'old cursor'});assert.equal(result.events[0].provider,'edisclosure');assert.equal(result.events[0].sourceType,'DISCLOSURE');assert.equal(result.events[0].isDemo,false);assert.equal(result.cursor,'next-1');assert.equal(new URL(request.url).searchParams.get('cursor'),'old cursor');assert.equal(request.options.apiKey,'unit-private-key');assert.ok(!JSON.stringify(provider).includes('unit-private-key'));assert.ok(!JSON.stringify(result).includes('unit-private-key'));
 await assert.rejects(createEndpointProvider({id:'nsd',sourceType:'NSD'}).fetchEvents(),{code:'RADAR_ENDPOINT_NOT_CONFIGURED'});
});
test('Radar official RSS/Atom normalization rejects entity expansion and malformed or oversized feeds',()=>{
 const rss='<?xml version="1.0"?><rss><channel><item><guid>1</guid><title><![CDATA[<b>Сбер</b>]]></title><link>https://www.moex.com/news/1</link><pubDate>Fri, 30 Oct 2026 10:00:00 GMT</pubDate><description><![CDATA[<p>Дивиденды</p>]]></description></item></channel></rss>';
 const result=parseProviderResponse({body:rss,contentType:'application/rss+xml'},{provider:'edisclosure',sourceType:'DISCLOSURE'});assert.equal(result.events[0].title,'Сбер');assert.equal(result.events[0].rawText,'Дивиденды');assert.equal(result.events[0].externalId,'1');assert.equal(result.events[0].publishedAt,'Fri, 30 Oct 2026 10:00:00 GMT');
 const atom='<feed><entry><id>a1</id><title>Отчёт</title><link href="https://www.moex.com/news/a1"/><updated>2026-10-30T10:00:00Z</updated><summary>Описание</summary></entry></feed>';assert.equal(parseProviderResponse({body:atom,contentType:'application/atom+xml'},{provider:'company-ir',sourceType:'IR'}).events[0].sourceUrl,'https://www.moex.com/news/a1');
 assert.throws(()=>parseProviderResponse({body:'<!DOCTYPE a [<!ENTITY x "boom">]><rss/>',contentType:'application/xml'},{provider:'nsd'}),{code:'RADAR_XML_ENTITY_REJECTED'});
 assert.throws(()=>parseProviderResponse({body:'{"events":[{}],"cursor":{}}',contentType:'application/json'},{provider:'nsd'}),{code:'RADAR_INVALID_CURSOR'});
 assert.throws(()=>parseProviderResponse({body:'a'.repeat(1048577),contentType:'text/html'},{provider:'nsd'}),{code:'RADAR_RESPONSE_LIMIT'});
 assert.throws(()=>parseProviderResponse({body:JSON.stringify({events:Array(101).fill({})}),contentType:'application/json'},{provider:'nsd'}),{code:'RADAR_FEED_LIMIT'});
});
test('Radar rejects large malformed RSS and repeated field openings without quadratic scans',()=>{
 const parse=body=>parseProviderResponse({body,contentType:'application/rss+xml'},{provider:'edisclosure',sourceType:'DISCLOSURE'}),started=performance.now();
 assert.throws(()=>parse('<rss>'+'<item>'.repeat(160000)+'</rss>'),{code:'RADAR_FEED_LIMIT'});
 for(const body of ['<rss><item><title>Незакрыто</rss>','<rss><item><item></item></item></rss>','<rss></item></rss>','<rss><item>'+'<title>'.repeat(100000)+'</item></rss>'])assert.throws(()=>parse(body),{code:'RADAR_INVALID_FEED'});
 assert.ok(performance.now()-started<1500,'Malformed feed should fail before expensive parsing');
});
test('Radar provider endpoint safety rejects private, mapped, credentialed and non-HTTPS origins before connecting',async()=>{
 for(const address of ['127.0.0.1','10.1.2.3','172.16.0.1','192.168.1.1','169.254.169.254','100.64.0.1','0.0.0.0','::1','::ffff:127.0.0.1','fe80::1','fec0::1','fd00::1','2001:db8::1','64:ff9b::7f00:1','2002:7f00:1::','2001::7f00:1'])assert.equal(publicIp(address),false,address);
 assert.equal(publicIp('8.8.8.8'),true);assert.equal(publicIp('2606:4700:4700::1111'),true);
 for(const url of ['http://www.moex.com/','https://127.1/','https://2130706433/','https://0x7f000001/','https://[::ffff:7f00:1]/','https://secret@www.moex.com/','https://www.moex.com:8443/','https://service.internal/']){assert.throws(()=>safeSourceUrl(url));await assert.rejects(safeHttpGet(url));}
});
test('Radar HTTP transport destroys redirect/error bodies, enforces response size, compression policy and deadline',async t=>{
 const scenarios=[{status:302,code:'RADAR_REDIRECT_REJECTED'},{status:500,code:'RADAR_PROVIDER_HTTP'},{status:200,headers:{'content-encoding':'gzip'},code:'RADAR_ENCODING_REJECTED'},{status:200,headers:{'content-length':'2000000'},code:'RADAR_RESPONSE_LIMIT'},{status:200,chunks:[Buffer.alloc(1048577)],code:'RADAR_RESPONSE_LIMIT'},{hang:true,code:'RADAR_PROVIDER_TIMEOUT'}];
 for(const scenario of scenarios){let request,response;const original=https.request;https.request=(url,options,callback)=>{request=new EventEmitter();request.destroyed=false;request.destroy=()=>{request.destroyed=true;};request.end=()=>{if(scenario.hang)return;queueMicrotask(()=>{response=new EventEmitter();response.statusCode=scenario.status;response.headers=scenario.headers||{};response.destroyed=false;response.destroy=()=>{response.destroyed=true;};callback(response);if(!response.destroyed){for(const chunk of scenario.chunks||[])response.emit('data',chunk);if(!response.destroyed)response.emit('end');}});};return request;};
  try{await assert.rejects(safeHttpGet('https://www.moex.com/feed',{timeoutMs:20}),{code:scenario.code});assert.equal(request.destroyed,true);if(response&&scenario.status!==200)assert.equal(response.destroyed,true);}finally{https.request=original;}
 }
});

test('built-in official feeds parse issuer dates, keep only recent material news and use stable links',async()=>{
 const now=()=>Date.parse('2026-11-26T12:00:00Z');
 const article=(title,link,date)=>'<item><title>'+title+'</title><link>'+link+'</link><pubDate>'+date+'</pubDate><description>Текст пресс-релиза</description></item>';
 const recent='Wed, 25 Nov 2026 10:00:00 +0300',link='https://ir.yandex.ru/press-releases?year=2026&amp;id=25-11-2026';
 const yandex={
  contentType:'application/rss+xml',
  body:'<rss><channel>'+article('Опубликованы финансовые результаты',link+'&amp;utm_source=rss',recent)+
   article('Опубликованы финансовые результаты',link+'#article',recent)+
   article('Яндекс обновил поисковое приложение',link+'-2',recent)+
   article('Опубликованы финансовые результаты',link+'-3','Tue, 10 Nov 2026 15:00:00 +0300')+
   article('Опубликованы финансовые результаты','https://ir.yandex.ru.example.org/press-releases',recent)+'</channel></rss>'
 };
 const x5={contentType:'application/json',body:JSON.stringify([{id:1,date_gmt:'2026-11-25T08:30:00',link:'https://www.x5.ru/ru/news/obligacii/',title:{rendered:'X5 разместила корпоративные облигации'},lang:'ru'}])};
 const polyus={contentType:'text/html',body:'<article class="news-item"><h3 class="news-item__title"><a href="/ru/media/press-releases/dividendy/">Решение о дивидендах</a></h3><time class="news-item__time" datetime="2026-11-25">25 ноября 2026 г., 15:00</time></article>'};
 const responses={'ir.yandex.ru':yandex,'www.x5.ru':x5,'polyus.com':polyus};
 const registry=createProviderRegistry({env:{RADAR_PROVIDER_MODE:'live'},now,requestImpl:async url=>responses[new URL(url).hostname]});
 const active=registry.filter(provider=>['official-yandex','official-x5','official-polyus'].includes(provider.id));
 const batches=await Promise.all(active.map(provider=>provider.fetchEvents()));
 assert.deepEqual(batches.map(batch=>batch.events.length),[1,1,1]);
 const events=batches.flatMap(batch=>batch.events);
 assert.deepEqual(events.map(event=>event.ticker),['YDEX','X5','PLZL']);
 assert.deepEqual(events.map(event=>event.publishedAt),['2026-11-25T07:00:00.000Z','2026-11-25T08:30:00.000Z','2026-11-25T12:00:00.000Z']);
 assert.ok(events.every(event=>!event.isDemo&&event.rawText===event.title));
 assert.equal(events[0].sourceUrl,'https://ir.yandex.ru/press-releases?year=2026&id=25-11-2026');
 assert.equal((await active[0].fetchEvents()).events[0].externalId,events[0].externalId);
});

test('expanded official providers keep day precision, normalize results and bound individual issuer responses',async()=>{
 const now=()=>Date.parse('2026-11-26T12:00:00Z');
 const panel=(date,link,title)=>'<div data-test="panels-0" role="listitem"><p>'+date+'</p><a data-test="panel-link" href="'+link+'">Отчёт</a><div><p>'+title+'</p></div></div>';
 const valid='https://cdn.tbank-online.com/static/documents/valid-press-release.pdf';
 const title='Операционные результаты Т-Технологий за октябрь 2026 года';
 const ttResponse=panel('24&nbsp;ноября 2026',valid,title)+panel('31 февраля 2026',valid,title)+panel('24 ноября 2026','https://cdn.tbank-online.com.example.org/static/documents/malicious.pdf',title);
 const flotResponse='<article class="press-list__item"><div class="press-list__date">20 ноября 2026 г.</div><h5 class="press-list__title"><a href="/media/press_releases/item123.html">Итоги работы ПАО «Совкомфлот» за 9 месяцев 2026 года</a></h5></article>';
 const providers=createProviderRegistry({env:{RADAR_PROVIDER_MODE:'live'},now,requestImpl:async (url,{maxResponseBytes})=>{
  const isT=new URL(url).hostname==='t-technologies.ru';
  assert.equal(maxResponseBytes,(isT?2:1)*1024*1024);
  return {body:isT?ttResponse:flotResponse,contentType:'text/html'};
 }});
 const pipeline=createPipeline({now});
 for(const [id,ticker,day] of [['official-t-technologies','T','2026-11-24'],['official-scf','FLOT','2026-11-20']]){
  const {events}=await providers.find(provider=>provider.id===id).fetchEvents();
  assert.equal(events.length,1);
  const event=await pipeline.process(events[0]);
  assert.equal(event.ticker,ticker);
  assert.equal(event.status,'published');
  assert.equal(event.eventType,'EARNINGS');
  assert.equal(event.publicationDay,day);
  assert.equal(event.sources[0].publicationDay,day);
  assert.equal(Date.parse(event.publishedAt),Date.parse(day+'T00:00:00+03:00'));
 }
});

test('Rostelecom chooses the Moscow calendar year and imports published company articles',async()=>{
 let clock=Date.parse('2026-12-31T20:59:00Z');
 const urls=[];
 const card=(day,month,category)=>'<div id="bx_8_15" class="item news_item"><a class="item_link" href="/ir/news_calendar/d123/"></a>'+
  '<span class="item_date-day">'+day+'</span><span class="item_date-month">'+month+'</span>'+
  '<div class="item_text">Финансовые результаты Ростелекома</div><a href="'+category+'">Категория</a></div>';
 const [provider]=createProviderRegistry({
  env:{RADAR_PROVIDER_MODE:'live'},
  now:()=>clock,
  requestImpl:async url=>{
   urls.push(url);
   const current=url.endsWith('/2026/');
   return {contentType:'text/html',body:card(current?'31':'1',current?'Декабря':'Января','/press/news/')+card('1','Января','/ir/calendar/')};
  }
 }).filter(item=>item.id==='official-rostelecom');
 const previous=await provider.fetchEvents();
 assert.deepEqual(previous.events.map(row=>row.publicationDay),['2026-12-31']);
 clock+=2*60*1000;
 const current=await provider.fetchEvents();
 assert.deepEqual(current.events.map(row=>row.publicationDay),['2027-01-01']);
 assert.deepEqual(urls.map(url=>new URL(url).pathname),['/ir/news_calendar/2026/','/ir/news_calendar/2027/']);
});
