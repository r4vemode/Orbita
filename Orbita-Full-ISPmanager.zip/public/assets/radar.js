(() => {
  'use strict';
  const $=id=>document.getElementById(id),A=window.OrbitaAccess;
  const types={DIVIDEND:'Дивиденды',EARNINGS:'Отчётность',GUIDANCE:'Прогноз бизнеса',BUYBACK:'Обратный выкуп',SPO:'SPO',SECONDARY_OFFERING:'Вторичное размещение',SHARE_ISSUE:'Дополнительная эмиссия',M_AND_A:'Слияния и поглощения',CONTRACT:'Контракт',BOARD_MEETING:'Совет директоров',BOARD_DECISION:'Решение совета',MANAGEMENT_CHANGE:'Руководство',CREDIT_RATING:'Кредитный рейтинг',DEFAULT:'Дефолт',TECHNICAL_DEFAULT:'Технический дефолт',BANKRUPTCY:'Банкротство',DEBT:'Долговые обязательства',BOND_COUPON:'Купон облигаций',BOND_OFFER:'Оферта облигаций',BOND_REDEMPTION:'Погашение облигаций',CAPEX:'Капитальные затраты',CORPORATE_ACTION:'Корпоративное действие',LEGAL:'Правовое событие',OTHER:'Другое'};
  const impacts={POSITIVE:['Позитивное','positive'],NEGATIVE:['Негативное','negative'],NEUTRAL:['Нейтральное','neutral'],MIXED:['Неоднозначное','mixed']};
  const params=new URLSearchParams(location.search),categories=new Set(['all','important','stocks','bonds','dividends','earnings','credit','ma']);
  let config=null,user=null,companies=[],subscriptions=[],events=[],category=categories.has(params.get('category'))?params.get('category'):'all',cursor=null,revision=null,stream=null,streamFailures=0,streamRetry=null,refreshTimer=null,filterTimer=null,toastTimer=null,accessTimer=null,feedController=null,detailController=null,feedSequence=0,detailSequence=0,busy=false,suspended=false,browserNotifications=false,toastEvent=null,detailEvent=null,lastFocus=null,subscriptionBusy=false,connectedAt=Date.now(),accessChecking=false;
  const node=(tag,className,text)=>{const value=document.createElement(tag);if(className)value.className=className;if(text!==undefined)value.textContent=String(text);return value;};
  const full=()=>config?.access?.tier==='pro';
  const requiredPlan=()=>config?.allowedPlans?.find(plan=>['pro','exclusive'].includes(plan))||'pro';
  const requiredPlanName=()=>A?.plans?.[requiredPlan()]?.name||'Orbita Pro';
  const number=value=>typeof value==='number'&&Number.isFinite(value)?new Intl.NumberFormat('ru-RU',{maximumFractionDigits:4}).format(value):'—';
  const percentage=value=>typeof value==='number'&&Number.isFinite(value)?(value>0?'+':'')+number(value)+'%':'Нет данных';
  const time=value=>Number.isFinite(Date.parse(value))?new Intl.DateTimeFormat('ru-RU',{timeZone:'Europe/Moscow',hour:'2-digit',minute:'2-digit'}).format(new Date(value)):'—';
  const date=value=>Number.isFinite(Date.parse(value))?new Intl.DateTimeFormat('ru-RU',{timeZone:'Europe/Moscow',day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(new Date(value))+' МСК':'Нет данных';
  const calendarScopes=[...document.querySelectorAll('[data-radar-calendar-scope]')];
  const calendarDate=new Intl.DateTimeFormat('ru-RU',{timeZone:'Europe/Moscow',day:'numeric',month:'short'});
  const dayOnly=new Intl.DateTimeFormat('ru-RU',{timeZone:'Europe/Moscow',day:'numeric',month:'short',year:'numeric'});
  const moscowISO=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Moscow',year:'numeric',month:'2-digit',day:'2-digit'});
  const publicationDate=value=>value.publicationDay?dayOnly.format(new Date(value.publishedAt)):date(value.publishedAt);
  const calendarDay=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Moscow',year:'numeric',month:'numeric',day:'numeric'});
  let calendarScope='all',calendarRequest=null;
  function delay(from,to){const value=Date.parse(to)-Date.parse(from);return Number.isFinite(value)&&value>=0?number(value/1000)+' с':'Нет данных';}
  function safeSource(value){try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password?url:null;}catch{return null;}}
  function connection(text,live=false){$('radarConnection').textContent=text;$('radarConnection').classList.toggle('live',live);}
  function showError(message){$('radarErrorText').textContent=message;$('radarError').hidden=false;}
  function preferenceStatus(message,error=false){$('radarPreferenceStatus').textContent=message;$('radarPreferenceStatus').classList.toggle('error',error);}
  function stopStream(){if(stream){stream.close();stream=null;}if(streamRetry){clearTimeout(streamRetry);streamRetry=null;}}
  function clearFeed(){events=[];cursor=null;revision=null;$('radarCards').replaceChildren();$('radarLoadMore').hidden=true;$('radarToast').hidden=true;toastEvent=null;}
  function closeDetail(){detailSequence++;detailController?.abort();detailController=null;detailEvent=null;if($('radarDetail').open)$('radarDetail').close();$('radarDetailContent').replaceChildren();$('radarDetailStatus').textContent='';const value=new URL(location.href);value.searchParams.delete('event');history.replaceState(null,'',value.pathname+value.search);if(lastFocus?.isConnected)lastFocus.focus();lastFocus=null;}
  function locked({guest=false,disabled=false,message}={}){
    stopStream();clearFeed();clearCalendar();setCalendarScope('all');feedSequence++;feedController?.abort();feedController=null;busy=false;subscriptions=[];browserNotifications=false;if(config)config={...config,access:{tier:'locked',realtime:false}};closeDetail();$('radarSkeleton').hidden=true;$('radarWorkspace').hidden=true;$('radarLocked').hidden=false;$('radarSubscribeLink').hidden=guest||disabled;$('radarLoginLink').hidden=!guest;connection(disabled?'Radar отключён':guest?'Войдите в аккаунт':'Нужна подписка');
    $('radarSubscribeLink').href='subscriptions.html?plan='+encodeURIComponent(requiredPlan())+'&next=%2Fradar.html';$('radarSubscribeLink').textContent='Выбрать '+requiredPlanName()+' ↗';
    $('radarLockedTitle').textContent=disabled?'Radar готовится к подключению':guest?'Войдите, чтобы открыть Radar':'Radar по подписке';$('radarLockedText').textContent=message||(disabled?'Раздел пока отключён. Вернитесь позже.':guest?'События и настройки доступны в вашем аккаунте.':'Для Radar нужна подписка '+requiredPlanName()+'. Доступ к другим стратегиям определяется отдельно.');
  }
  async function api(path,options={}){
    let response;try{response=await fetch(path,{credentials:'same-origin',cache:'no-store',...options,headers:{'Content-Type':'application/json',...options.headers}});}catch(cause){if(cause.name==='AbortError')throw cause;throw Error('Не удалось связаться с Radar. Проверьте соединение и повторите загрузку.');}
    let data;try{data=await response.json();}catch{throw Error('Не удалось получить ответ Radar. Повторите попытку.');}
    if(response.status===401){locked({guest:true});throw Object.assign(Error('Войдите в аккаунт.'),{status:401});}
    if(response.status===403){locked({message:data.error});throw Object.assign(Error(data.error||'Для Radar нужна подписка.'),{status:403});}
    if(!response.ok)throw Object.assign(Error(A?.supportMessage(data,'Не удалось выполнить запрос Radar.')||data.error||'Не удалось выполнить запрос.'),{status:response.status,code:data.code});return data;
  }
  function setCalendarScope(scope){
    calendarScope=scope;
    for(const button of calendarScopes)button.setAttribute('aria-pressed',String(button.dataset.radarCalendarScope===scope));
  }
  function calendarStatus(message){
    const status=$('radarCalendarStatus');status.textContent=message;status.hidden=!message;
  }
  function clearCalendar(){
    calendarRequest?.abort();calendarRequest=null;
    for(const id of ['radarCalendarUpcoming','radarCalendarResults'])$(id).replaceChildren();
    for(const id of ['radarCalendarUpcomingEmpty','radarCalendarResultsEmpty'])$(id).hidden=true;
    $('radarCalendarLists').setAttribute('aria-busy','false');calendarStatus('');
  }
  function moscowDay(value){
    const parts=Object.fromEntries(calendarDay.formatToParts(value).map(part=>[part.type,part.value]));
    return Date.UTC(Number(parts.year),Number(parts.month)-1,Number(parts.day));
  }
  function calendarRow(event,showOutcome){
    const row=node('li','radar-calendar-row'),identity=node('div','radar-calendar-identity');
    identity.append(node('strong','',event.ticker||'Эмитент'),node('span','',types[event.eventType]||'Корпоративное событие'));
    if(event.isDemo)identity.append(node('span','','Демонстрация'));
    const body=node('div','radar-calendar-body'),headline=node('button','radar-calendar-event',event.headline||'Корпоративное событие');
    headline.type='button';headline.addEventListener('click',()=>void openDetail(event.id,headline));body.append(identity,headline);
    if(showOutcome){
      body.append(node('p','radar-calendar-outcome',event.outcome.text));
      const source=safeSource(event.outcome.source);
      if(source){const link=node('a','radar-text-link','Источник итога ↗');link.href=source.href;link.target='_blank';link.rel='noopener noreferrer';body.append(link);}
    }
    row.append(body);
    const outcomeAt=showOutcome&&event.outcome.publishedAt;
    const at=Date.parse(outcomeAt||event.scheduledAt);
    if(Number.isFinite(at)){
      const stamp=node('time','radar-calendar-date',calendarDate.format(at));stamp.dateTime=new Date(at).toISOString();
      if(showOutcome)stamp.title=outcomeAt?'Дата публикации итога':'Дата события';
      else if(!event.scheduledAllDay)stamp.append(node('span','',time(stamp.dateTime)+' МСК'));
      row.append(stamp);
    }
    return row;
  }
  function renderCalendar(events){
    const now=Date.now(),firstDay=moscowDay(now),nextWeek=firstDay+7*86400000;
    const upcoming=events.filter(event=>{
      const at=Date.parse(event.scheduledAt);if(event.outcome?.text||!Number.isFinite(at))return false;
      const day=moscowDay(at);return day>=firstDay&&day<nextWeek&&(event.scheduledAllDay||at>=now);
    }).sort((a,b)=>Date.parse(a.scheduledAt)-Date.parse(b.scheduledAt));
    const results=events.filter(event=>typeof event.outcome?.text==='string'&&event.outcome.text.trim())
      .sort((a,b)=>Date.parse(b.outcome.publishedAt||b.scheduledAt||b.publishedAt)-Date.parse(a.outcome.publishedAt||a.scheduledAt||a.publishedAt));
    $('radarCalendarUpcoming').replaceChildren(...upcoming.map(event=>calendarRow(event,false)));
    $('radarCalendarResults').replaceChildren(...results.map(event=>calendarRow(event,true)));
    const upcomingEmpty=$('radarCalendarUpcomingEmpty'),resultsEmpty=$('radarCalendarResultsEmpty');
    upcomingEmpty.textContent=calendarScope==='mine'?'По вашим бумагам пока нет ближайших событий.':'Подтверждённых дат пока нет.';
    resultsEmpty.textContent=calendarScope==='mine'?'По вашим бумагам пока нет опубликованных итогов.':'Пока нет опубликованных итогов.';
    upcomingEmpty.hidden=upcoming.length>0;resultsEmpty.hidden=results.length>0;
  }
  async function loadCalendar(){
    if(!config?.enabled||!full()||suspended)return;
    calendarRequest?.abort();const request=new AbortController();calendarRequest=request;
    $('radarCalendarLists').setAttribute('aria-busy','true');calendarStatus('Загружаем календарь…');
    try{
      const result=await api('/api/radar/calendar'+(calendarScope==='mine'?'?watchlist=mine':''),{signal:request.signal});
      if(calendarRequest!==request||suspended||!full())return;
      renderCalendar(Array.isArray(result.events)?result.events:[]);calendarStatus('');
    }catch(cause){
      if(calendarRequest===request&&cause.name!=='AbortError'&&![401,403].includes(cause.status))calendarStatus('Календарь недоступен. Нажмите «Обновить», чтобы повторить загрузку.');
    }finally{
      if(calendarRequest===request){calendarRequest=null;$('radarCalendarLists').setAttribute('aria-busy','false');}
    }
  }
  function severity(value){return value>=9?'critical':value>=7?'high':value>=5?'medium':'low';}
  function score(value){return typeof value==='number'&&Number.isFinite(value)?new Intl.NumberFormat('ru-RU',{minimumFractionDigits:1,maximumFractionDigits:1}).format(value)+' / 10':'Оценка уточняется';}
  function impactBadge(value){const [text,className]=impacts[value]||impacts.NEUTRAL;return node('span','radar-impact '+className,text);}
  function companyName(id){const item=companies.find(value=>value.id===id);return item?item.ticker+' · '+(item.shortName||item.name):'Компания';}
  function isFollowed(companyId){return subscriptions.some(value=>value.enabled&&value.companyId===companyId);}
  function renderCard(event){
    const card=node('article','radar-card '+(full()?severity(event.importanceScore):''));card.dataset.radarEvent=event.id;
    const top=node('div','radar-card-top'),identity=node('div','radar-card-identity');identity.append(node('strong','radar-card-ticker',event.ticker||'Эмитент'),node('span','radar-card-company',(event.companyName||'Компания уточняется')+(event.assetType==='bond'?' · облигации':'')+(event.following?' · В отслеживании':'')));const clock=node('time','radar-card-time',event.publicationDay?calendarDate.format(new Date(event.publishedAt)):time(event.publishedAt));if(Number.isFinite(Date.parse(event.publishedAt)))clock.dateTime=event.publicationDay||event.publishedAt;clock.title=publicationDate(event);top.append(identity,clock);
    const heading=node('h2'),open=node('button','radar-open-event',event.headline||'Корпоративное событие');open.type='button';open.addEventListener('click',()=>openDetail(event.id,open));heading.append(open);
    const labels=node('div','radar-card-signals');labels.append(impactBadge(event.impact));if(full())labels.append(node('span','radar-score',(event.importanceScore>=9?'Критическое · ':event.importanceScore>=7?'Высокая · ':'Значимость · ')+score(event.importanceScore)));
    const footer=node('div','radar-card-footer'),caption=node('span','',event.isDemo?'ДЕМОНСТРАЦИЯ':types[event.eventType]||'Корпоративное событие');if(event.isDemo)caption.className='radar-card-label';const details=node('button','',full()?'Разобраться →':'Полный разбор · Pro ↗');details.type='button';details.addEventListener('click',()=>openDetail(event.id,details));footer.append(caption,details);
    card.append(top,heading);
    if(event.summary&&event.summary!==event.headline)card.append(node('p','radar-card-summary',event.summary));
    card.append(labels,footer);return card;
  }
  function renderCards(){const fragment=document.createDocumentFragment();for(const event of events)fragment.append(renderCard(event));$('radarCards').replaceChildren(fragment);$('radarEmpty').hidden=events.length>0;$('radarResultCount').textContent=events.length?'Событий показано: '+events.length:'Событий по фильтрам пока нет';$('radarLoadMore').hidden=!cursor;$('radarLoadMore').disabled=busy;}
  function matchesSubscription(event){const published=Date.parse(event.notificationAt||event.firstPublishedAt||event.processedAt);const inSession=event.publicationDay?event.publicationDay>=moscowISO.format(connectedAt):published>=connectedAt-1000;return inSession&&subscriptions.some(value=>value.enabled&&published>=Date.parse(value.createdAt)&&(!value.companyId||value.companyId===event.companyId)&&(!value.eventType||value.eventType===event.eventType)&&event.importanceScore>=Math.max(6,value.minimumImportance||9));}
  function notifyNewEvent(event){
    if(!config?.notificationsEnabled||!full()||!Number.isFinite(Date.parse(event.detectedAt))||Date.parse(event.detectedAt)<connectedAt-1000||document.hidden)return;
    toastEvent=event;$('radarToastText').textContent=(event.isDemo?'Демонстрация · ':'')+(event.ticker||'Radar')+': '+event.headline;$('radarToast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>{$('radarToast').hidden=true;},12000);
    if(browserNotifications&&'Notification'in window&&Notification.permission==='granted'){try{const alert=new Notification((event.isDemo?'Демо · ':'')+'Signals Radar · '+(event.ticker||''),{body:event.headline,tag:'radar-'+event.id});alert.onclick=()=>{window.focus();openDetail(event.id);alert.close();};}catch{}}
  }
  function query(next){const value=new URLSearchParams({category,limit:full()?'20':'5'}),search=$('radarSearch').value.trim(),company=$('radarCompany').value;if(search)value.set('q',search);if(company)value.set('company',company);if(full()){value.set('importance',$('radarImportance').value);if($('radarImpact').value)value.set('impact',$('radarImpact').value);if($('radarWatchlist').checked)value.set('watchlist','1');}if(next)value.set('cursor',next);return value;}
  async function loadFeed({more=false,live=false}={}){
    if(!config?.enabled||!['pro','free'].includes(config?.access?.tier)||suspended)return;
    const previous=new Set(events.map(event=>event.id)),sequence=++feedSequence;feedController?.abort();feedController=new AbortController();busy=true;$('radarError').hidden=true;$('refreshRadar').disabled=true;$('radarLoadMore').disabled=true;$('radarCards').setAttribute('aria-busy','true');if(!events.length)$('radarSkeleton').hidden=false;
    try{const result=await api('/api/radar?'+query(more?cursor:null),{signal:feedController.signal});if(sequence!==feedSequence||suspended)return;const rows=Array.isArray(result.events)?result.events:[];events=more?[...events,...rows.filter(value=>!previous.has(value.id))]:rows;cursor=typeof result.nextCursor==='string'&&result.nextCursor?result.nextCursor:null;revision=result.revision;renderCards();if(live&&full()&&config.notificationsEnabled){try{await loadSubscriptions();}catch{return;}if(sequence!==feedSequence||suspended||!full())return;const fresh=rows.find(event=>!previous.has(event.id)&&matchesSubscription(event));if(fresh)notifyNewEvent(fresh);}connection(config.access.realtime&&stream?.readyState===1?'Обновляется автоматически':config.access.tier==='free'?'Лента с задержкой':config.mode==='live'?'Данные загружены':'Локальная лента',config.access.realtime&&stream?.readyState===1);}
    catch(cause){if(cause.name!=='AbortError'&&![401,403].includes(cause.status)&&sequence===feedSequence)showError(cause.message);}
    finally{if(sequence===feedSequence){busy=false;feedController=null;$('radarSkeleton').hidden=true;$('radarCards').setAttribute('aria-busy','false');$('refreshRadar').disabled=false;$('radarLoadMore').disabled=false;}}
  }
  function scheduleRefresh(){if(refreshTimer)return;refreshTimer=setTimeout(()=>{refreshTimer=null;void loadFeed({live:true});void loadCalendar();},350);}
  function startStream(){
    stopStream();if(suspended||document.hidden||!config?.enabled||!full()||!config.access.realtime||!('EventSource'in window))return;
    const current=new EventSource('/api/radar/stream');stream=current;
    const receive=event=>{if(stream!==current||suspended)return;let value;try{value=JSON.parse(event.data);}catch{return;}if(!Number.isSafeInteger(value?.revision))return;if(revision!==null&&value.revision!==revision)scheduleRefresh();connection('Обновляется автоматически',true);streamFailures=0;};
    current.addEventListener('ready',receive);current.addEventListener('radar-update',receive);current.onopen=()=>{if(stream===current){streamFailures=0;connection('Обновляется автоматически',true);}};
    current.onerror=()=>{if(stream!==current)return;connection('Восстанавливаем связь');streamFailures++;void checkAccess();if(streamFailures>=5){stopStream();connection('Связь прервана · обновите ленту');}};
  }
  async function checkAccess(){if(accessChecking||suspended||document.hidden)return;accessChecking=true;try{const account=await A.current();if(!account){locked({guest:true});return;}const changedAccount=user?.id!==account.id,previousTier=config?.access?.tier;user=account;const next=await api('/api/radar/config');config=next;if(!next.enabled){locked({disabled:true});return;}if(!['pro','free'].includes(next.access?.tier)){locked();return;}if(changedAccount||previousTier!==next.access.tier){stopStream();clearFeed();closeDetail();clearCalendar();setCalendarScope('all');subscriptions=[];browserNotifications=false;applyConfig();if(full())await loadSubscriptions();await Promise.all([loadFeed(),loadCalendar()]);startStream();}else if(!full())stopStream();}catch(cause){if(![401,403].includes(cause.status))connection('Нет связи с сервером');}finally{accessChecking=false;}}
  function setCategory(value){category=categories.has(value)?value:'all';document.querySelectorAll('[data-category]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.category===category)));}
  function renderCompanies(){for(const id of ['radarCompany','subscriptionCompany']){const select=$(id),selected=select.value;select.replaceChildren(new Option('Все компании',''));for(const item of companies)if(item.active!==false)select.add(new Option(item.ticker+' · '+(item.shortName||item.name),item.id));if([...select.options].some(option=>option.value===selected))select.value=selected;}}
  function renderSubscriptions(){
    const holder=$('radarSubscriptions');holder.replaceChildren();const active=subscriptions.filter(value=>value.enabled);$('radarFollowCount').textContent=active.length?'Правил: '+active.length:'';if(!active.length)holder.append(node('p','radar-small','Пока нет правил. Уведомления о событиях не включены.'));
    for(const value of active){const row=node('div','radar-subscription'),text=node('span','',(value.companyId?companyName(value.companyId):'Все компании')+' · '+(types[value.eventType]||'Все события')+' · от '+number(value.minimumImportance));const remove=node('button','','×');remove.type='button';remove.setAttribute('aria-label','Удалить правило '+(value.companyId?companyName(value.companyId):'для всех компаний'));remove.disabled=subscriptionBusy;remove.addEventListener('click',()=>removeSubscription(value.id));row.append(text,remove);holder.append(row);}if(detailEvent)updateFollowButton();
  }
  async function loadSubscriptions(){if(!full())return;const result=await api('/api/radar/subscriptions');subscriptions=Array.isArray(result.subscriptions)?result.subscriptions:[];renderSubscriptions();}
  async function addSubscription(payload){if(subscriptionBusy)return;subscriptionBusy=true;$('saveRadarSubscription').disabled=true;renderSubscriptions();try{await api('/api/radar/subscriptions',{method:'POST',body:JSON.stringify(payload)});await loadSubscriptions();if(calendarScope==='mine')void loadCalendar();preferenceStatus(config.notificationsEnabled?'Правило сохранено. События будут отбираться по вашим настройкам.':'Правило сохранено. Доставка уведомлений пока отключена; компании остаются в отслеживании.');}catch(cause){if(![401,403].includes(cause.status))preferenceStatus(cause.message,true);throw cause;}finally{subscriptionBusy=false;$('saveRadarSubscription').disabled=false;renderSubscriptions();}}
  async function removeSubscription(id){if(subscriptionBusy)return;subscriptionBusy=true;renderSubscriptions();try{await api('/api/radar/subscriptions/'+encodeURIComponent(id),{method:'DELETE'});await loadSubscriptions();if(calendarScope==='mine')void loadCalendar();preferenceStatus('Правило удалено.');}catch(cause){if(![401,403].includes(cause.status))preferenceStatus(cause.message,true);}finally{subscriptionBusy=false;renderSubscriptions();}}
  function fact(grid,label,value){const item=node('div');item.append(node('dt','',label),node('dd','',value));grid.append(item);}
  function section(title){const item=node('section','radar-detail-section');item.append(node('h3','',title));return item;}
  function updateFollowButton(){const button=$('radarFollowCompany');if(!button||!detailEvent)return;button.textContent=isFollowed(detailEvent.companyId)?'Компания в отслеживании ✓':'Следить за компанией +';button.disabled=subscriptionBusy||isFollowed(detailEvent.companyId)||!detailEvent.companyId;button.setAttribute('aria-pressed',String(isFollowed(detailEvent.companyId)));}
  function renderDetail(event){
    detailEvent=event;const holder=$('radarDetailContent');holder.replaceChildren();const identity=node('div','radar-detail-identity'),company=node('div'),ticker=node('h2','',event.ticker||'Эмитент');company.append(ticker,node('p','',event.companyName||'Компания уточняется'));if(event.isin)company.append(node('p','radar-small','ISIN: '+event.isin));const follow=node('button','radar-outline');follow.type='button';follow.id='radarFollowCompany';follow.addEventListener('click',async()=>{if(!detailEvent?.companyId)return;try{await addSubscription({companyId:detailEvent.companyId,eventType:null,minimumImportance:6,enabled:true});$('radarDetailStatus').textContent='Компания добавлена в отслеживание.';}catch(cause){if(![401,403].includes(cause.status))$('radarDetailStatus').textContent=cause.message;}});identity.append(company,follow);holder.append(identity);updateFollowButton();
    const companyLink=node('a','radar-text-link','Все события компании →');companyLink.href='radar.html?ticker='+encodeURIComponent(event.ticker||'');companyLink.addEventListener('click',click=>{if(!event.companyId)return;click.preventDefault();$('radarCompany').value=event.companyId;closeDetail();void loadFeed();});holder.append(companyLink);
    const headline=node('h2','radar-detail-headline',event.headline);headline.id='radarDetailTitle';holder.append(headline);const labels=node('div','radar-detail-labels');labels.append(impactBadge(event.impact),node('span','radar-score','Значимость '+score(event.importanceScore)),node('span','radar-small',types[event.eventType]||'Корпоративное событие'));holder.append(labels);
    if(event.isDemo)holder.append(node('p','radar-mode','Пример события с вымышленными данными.'));
    if(event.summary&&event.summary!==event.headline){const what=section('Что произошло');what.append(node('p','',event.summary));holder.append(what);}
    const why=section('Почему это важно');why.append(node('p','',event.whyImportant||'Контекст уточняется. Необходимо проверить первоисточник.'));holder.append(why);
    const analysis=node('p','radar-small',event.analysisMethod==='ai'?'Анализ AI · уверенность '+(Number.isFinite(event.confidence)?number(event.confidence*100)+'%':'уточняется')+'. Требует проверки.':event.analysisMethod==='manual'?'Пояснение подготовлено редакцией.':'Автоматический анализ по правилам. Внешний AI для этого события не использовался.');holder.append(analysis);
    const dates=section('Время и скорость'),timing=node('dl','radar-detail-facts');fact(timing,'Источник опубликовал',publicationDate(event));fact(timing,'Radar обнаружил',date(event.detectedAt));fact(timing,'Обработано',date(event.processedAt));if(!event.publicationDay)fact(timing,'Источник → Radar',delay(event.publishedAt,event.detectedAt));fact(timing,'Обработка Radar',delay(event.detectedAt,event.processedAt));fact(timing,'Уведомление отправлено',event.notificationSentAt?date(event.notificationSentAt):'Не отправлялось');if(event.notificationSentAt)fact(timing,'Обработка → уведомление',delay(event.processedAt,event.notificationSentAt));dates.append(timing);holder.append(dates);
    const data=section('Параметры события'),values=node('dl','radar-detail-facts');let valueCount=0;for(const [label,value]of [['Фактическое значение',event.actualValue],['Ожидание',event.expectedValue],['Предыдущее значение',event.previousValue]])if(typeof value==='number'&&Number.isFinite(value)){fact(values,label,number(value)+(event.eventType==='DIVIDEND'?' ₽':''));valueCount++;}if(typeof event.surprisePercent==='number'&&Number.isFinite(event.surprisePercent)){fact(values,'Отклонение от ожидания',percentage(event.surprisePercent));valueCount++;}
    const extracted=event.extractedData&&typeof event.extractedData==='object'&&!Array.isArray(event.extractedData)?event.extractedData:{};const dataLabels={dividend:'Дивиденд',dividendPerShare:'Дивиденд на акцию',dividendAmount:'Дивиденд',coupon:'Купон',couponAmount:'Купон',currency:'Валюта',recordDate:'Дата закрытия реестра',paymentDate:'Дата выплаты',revenue:'Выручка',ebitda:'EBITDA',profit:'Прибыль',couponRate:'Купонная ставка',rating:'Рейтинг',previousRating:'Предыдущий рейтинг',amount:'Сумма',yield:'Доходность',direction:'Изменение',canceled:'Отмена',cancelled:'Отмена'};
    for(const [key,value]of Object.entries(extracted).slice(0,12)){if(!Object.hasOwn(dataLabels,key)||value===null||value===undefined||typeof value==='object')continue;fact(values,dataLabels[key],typeof value==='number'?number(value):typeof value==='boolean'?value?'Да':'Нет':String(value));valueCount++;}if(valueCount)data.append(values);else data.append(node('p','', 'Подтверждённых числовых параметров пока нет. Ожидания и сравнение с рынком не подставляются автоматически.'));holder.append(data);
    const market=section('Реакция рынка'),reaction=event.marketReaction;if(reaction&&config.marketReactionEnabled!==false){const grid=node('div','radar-detail-reactions');for(const [suffix,label]of [['1m','1 минута'],['5m','5 минут'],['15m','15 минут'],['1h','1 час'],['1d','1 день']]){const block=node('div','radar-reaction'),change=reaction['change'+suffix];block.append(node('small','',label),node('strong',change>0?'positive':change<0?'negative':'',percentage(change)));grid.append(block);}market.append(grid,node('p','radar-small',reaction.isDemo||event.isDemo?'Вымышленный пример реакции рынка.':'Изменение относительно цены до события. Связь с публикацией не доказывает причину движения.'));if(Number.isFinite(reaction.priceBefore))market.append(node('p','radar-small','Цена до события: '+number(reaction.priceBefore)));}else market.append(node('p','','Котировки пока не подключены. Реакция рынка не рассчитана.'));holder.append(market);
    const sources=section('Источники'),sourceList=node('div','radar-detail-sources');for(const source of (Array.isArray(event.sources)?event.sources:[])){const row=node('div','radar-source'),url=safeSource(source.url);if(url){const link=node('a','',event.isDemo?'Открыть сайт источника ↗':'Открыть источник ↗');link.href=url.href;link.target='_blank';link.rel='noopener noreferrer';row.append(link,node('small','',(source.provider||'Источник')+' · '+url.hostname));}else row.append(node('span','','Ссылка на источник не предоставлена'));if(source.rawTitle)row.append(node('span','',source.rawTitle));if(source.publishedAt)row.append(node('small','',publicationDate(source)));sourceList.append(row);}if(!sourceList.childNodes.length)sourceList.append(node('p','','Источник пока не указан.'));sources.append(sourceList);if(event.isDemo)sources.append(node('p','radar-small','Ссылки демонстрации ведут на сайты источников и не подтверждают вымышленное событие.'));holder.append(sources);
    if(event.rawText&&event.rawText!==event.headline){const raw=node('details','radar-raw-text');raw.append(node('summary','','Исходный текст'),node('p','',event.rawText));holder.append(raw);}
  }
  async function openDetail(id,opener){
    if(!full()){locked({message:'Полный разбор события, значимость, история и реакция рынка доступны по подписке Orbita Pro.'});return;}
    const sequence=++detailSequence;detailController?.abort();detailController=new AbortController();lastFocus=opener||document.activeElement;$('radarDetailStatus').textContent='Загружаем событие…';$('radarDetailContent').replaceChildren(node('h2','radar-detail-headline','Событие Radar'));$('radarDetailContent').firstChild.id='radarDetailTitle';if(!$('radarDetail').open)$('radarDetail').showModal();
    try{const result=await api('/api/radar/'+encodeURIComponent(id),{signal:detailController.signal});if(sequence!==detailSequence||suspended||!$('radarDetail').open)return;if(!result.event)throw Error('Событие не найдено.');renderDetail(result.event);$('radarDetailStatus').textContent='';const value=new URL(location.href);value.searchParams.set('event',id);history.replaceState(null,'',value.pathname+value.search);}
    catch(cause){if(cause.name!=='AbortError'&&![401,403].includes(cause.status)&&sequence===detailSequence)$('radarDetailStatus').textContent=cause.message;}
    finally{if(sequence===detailSequence)detailController=null;}
  }
  function applyConfig(){
    $('radarLocked').hidden=true;$('radarWorkspace').hidden=false;const isFull=full();document.querySelectorAll('[data-radar-advanced]').forEach(value=>value.hidden=!isFull);$('radarPreferences').hidden=!isFull;document.querySelectorAll('[data-category]').forEach(button=>button.hidden=!isFull&&!['all','stocks','bonds'].includes(button.dataset.category));if(!isFull&&!['all','stocks','bonds'].includes(category))setCategory('all');
    $('radarCalendar').hidden=!isFull;
    $('radarMode').hidden=false;if(config.mode==='mock')$('radarMode').textContent='Демонстрационная лента с вымышленными событиями и ценами.';else if(config.mode==='off')$('radarMode').textContent='Редакция публикует события по первоисточникам.';else $('radarMode').textContent='Корпоративные новости поступают из официальных источников автоматически.';
    if(!isFull){$('radarMode').textContent+=' Доступна сокращённая лента с задержкой '+number((config.freeDelaySeconds||0)/60)+' мин.';$('radarFeedCaption').textContent='Ограниченная лента с задержкой';}else $('radarFeedCaption').textContent='Значимые события · сначала новые';
    $('radarNotificationExplanation').textContent=config.notificationsEnabled?'Уведомления учитывают ваши правила и действующий доступ. Отслеживание компании сохраняется в вашем аккаунте.':'Доставка уведомлений сейчас недоступна. Отслеживание компаний и правила можно сохранить.';$('enableRadarBrowser').disabled=!config.notificationsEnabled||!('Notification'in window);if(!('Notification'in window))$('enableRadarBrowser').textContent='Браузерные уведомления недоступны';
  }
  async function bootstrap(){
    suspended=false;$('refreshRadar').disabled=true;try{const nextUser=await A.current();if(!nextUser){locked({guest:true});return;}if(user&&nextUser.id!==user.id){clearFeed();closeDetail();clearCalendar();setCalendarScope('all');subscriptions=[];browserNotifications=false;}user=nextUser;config=await api('/api/radar/config');if(!config.enabled){locked({disabled:true});return;}if(!['pro','free'].includes(config.access?.tier)){locked();return;}if(!full())clearCalendar();applyConfig();const companyData=await api('/api/radar/companies');companies=Array.isArray(companyData.companies)?companyData.companies:[];renderCompanies();const ticker=params.get('ticker');if(ticker){const company=companies.find(value=>value.ticker===ticker.toUpperCase());if(company)$('radarCompany').value=company.id;}
      if(full())try{await loadSubscriptions();}catch(cause){if([401,403].includes(cause.status))return;preferenceStatus('Не удалось загрузить правила. Повторите открытие настроек.',true);}await Promise.all([loadFeed(),loadCalendar()]);startStream();if(params.get('event')&&full())await openDetail(params.get('event'));clearInterval(accessTimer);accessTimer=setInterval(()=>{void checkAccess();},20000);
    }catch(cause){if(![401,403].includes(cause.status)){showError(cause.message);$('radarWorkspace').hidden=false;$('radarSkeleton').hidden=true;connection('Не удалось загрузить Radar');}}finally{$('refreshRadar').disabled=false;}
  }
  document.querySelectorAll('[data-category]').forEach(button=>button.addEventListener('click',()=>{setCategory(button.dataset.category);void loadFeed();}));
  $('radarFilters').addEventListener('submit',event=>{event.preventDefault();clearTimeout(filterTimer);void loadFeed();});$('radarSearch').addEventListener('input',()=>{clearTimeout(filterTimer);filterTimer=setTimeout(()=>{void loadFeed();},300);});for(const id of ['radarCompany','radarImpact','radarImportance','radarWatchlist'])$(id).addEventListener('change',()=>{void loadFeed();});
  $('refreshRadar').addEventListener('click',async()=>{if(!config||!['pro','free'].includes(config.access?.tier)){await bootstrap();return;}await checkAccess();if(['pro','free'].includes(config?.access?.tier)){await Promise.all([loadFeed(),loadCalendar()]);if(!stream)startStream();}});$('retryRadar').addEventListener('click',()=>{if(!config||!companies.length)void bootstrap();else void loadFeed();});$('radarLoadMore').addEventListener('click',()=>{if(!busy&&cursor)void loadFeed({more:true});});
  for(const button of calendarScopes)button.addEventListener('click',()=>{
    const scope=button.dataset.radarCalendarScope;if(scope===calendarScope)return;
    clearCalendar();setCalendarScope(scope);void loadCalendar();
  });
  $('radarCalendarPreferences').addEventListener('click',()=>{
    const preferences=$('radarPreferences');preferences.open=true;preferences.querySelector('summary').focus();preferences.scrollIntoView({block:'start'});
  });
  $('resetRadarFilters').addEventListener('click',()=>{$('radarFilters').reset();setCategory('all');void loadFeed();});
  $('radarSubscriptionForm').addEventListener('submit',event=>{event.preventDefault();void addSubscription({companyId:$('subscriptionCompany').value||null,eventType:$('subscriptionType').value||null,minimumImportance:Number($('subscriptionImportance').value),enabled:true}).catch(()=>{});});
  $('radarPreferences').addEventListener('toggle',()=>{if($('radarPreferences').open&&full())void loadSubscriptions().catch(cause=>{if(![401,403].includes(cause.status))preferenceStatus(cause.message,true);});});
  $('enableRadarBrowser').addEventListener('click',async()=>{if(!config?.notificationsEnabled||!full()||!('Notification'in window))return;if(!subscriptions.some(value=>value.enabled)){preferenceStatus('Сначала добавьте правило: компанию, тему или все значимые события.');return;}try{const result=await Notification.requestPermission();browserNotifications=result==='granted';$('enableRadarBrowser').textContent=browserNotifications?'Браузерные уведомления включены ✓':'Разрешение на уведомления не получено';preferenceStatus(browserNotifications?'Уведомления включены для этой открытой вкладки.':'Разрешение можно изменить в настройках браузера.');}catch{preferenceStatus('Не удалось включить браузерные уведомления. Проверьте разрешения сайта.',true);}});
  $('closeRadarDetail').addEventListener('click',closeDetail);$('radarDetail').addEventListener('cancel',event=>{event.preventDefault();closeDetail();});$('radarDetail').addEventListener('click',event=>{if(event.target===$('radarDetail')){const rect=event.target.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)closeDetail();}});
  $('openRadarToast').addEventListener('click',()=>{if(toastEvent)void openDetail(toastEvent.id,$('openRadarToast'));$('radarToast').hidden=true;});$('closeRadarToast').addEventListener('click',()=>{$('radarToast').hidden=true;});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){stopStream();clearCalendar();$('radarToast').hidden=true;}else if(!suspended)void bootstrap();});window.addEventListener('pagehide',()=>{suspended=true;stopStream();feedSequence++;detailSequence++;feedController?.abort();detailController?.abort();clearCalendar();clearTimeout(refreshTimer);clearTimeout(filterTimer);clearTimeout(toastTimer);clearInterval(accessTimer);});window.addEventListener('pageshow',event=>{if(event.persisted)location.reload();});setCategory(category);void bootstrap();
})();
