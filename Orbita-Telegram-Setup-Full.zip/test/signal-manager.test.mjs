import test from 'node:test';
import assert from 'node:assert/strict';
import {positionSize,positionText} from '../lib/position-size.mjs';
import {radarPersonal,personalSettings} from '../lib/notifications.mjs';
import {isTelegramClientAction} from '../lib/telegram-client/menu.mjs';

test('stock position size follows risk, rounds to lots and never exceeds capital',()=>{
  const r=positionSize({entry:300,stop:294,target:315,market:'stocks'},{capital:1000000,riskPercent:1},{kind:'stock',lotSize:10});
  assert.equal(r.quantity,1660);assert.equal(r.loss,9960);assert.equal(r.rr,2.5);assert.equal(r.capped,false);
  const capped=positionSize({entry:300,stop:299.9,market:'stocks'},{capital:100000,riskPercent:2},{kind:'stock',lotSize:1});
  assert.equal(capped.capped,true);assert.ok(capped.value<=100000);
});

test('futures size uses point value and margin',()=>{
  const r=positionSize({entry:90000,stop:89500,target:91000,market:'futures'},{capital:500000,riskPercent:1},{kind:'future',stepPrice:1,minStep:1,margin:12000});
  assert.equal(r.quantity,10);assert.equal(r.margin,120000);
  assert.match(positionText({ticker:'SiZ6',dir:'ЛОНГ',entry:90000,stop:89500,target:91000,market:'futures',unit:'пт'},{capital:500000,riskPercent:1},{kind:'future',stepPrice:1,minStep:1,margin:12000}),/10 контр/);
});

test('personal Radar filters: importance, event groups, watchlist',()=>{
  const p={radarMinImportance:7,radarTypes:['dividends'],radarWatchOnly:true,watchTickers:['SBER']};
  assert.equal(radarPersonal(p,{ticker:'SBER',eventType:'DIVIDEND',importanceScore:8}),true);
  assert.equal(radarPersonal(p,{ticker:'SBER',eventType:'DIVIDEND',importanceScore:6}),false);
  assert.equal(radarPersonal(p,{ticker:'SBER',eventType:'EARNINGS',importanceScore:9}),false);
  assert.equal(radarPersonal(p,{ticker:'GAZP',eventType:'DIVIDEND',importanceScore:9}),false);
  assert.equal(radarPersonal({},{ticker:'GAZP',eventType:'OTHER',importanceScore:1}),true);
  assert.deepEqual(personalSettings({}).watchTickers,[]);
});

test('calculator buttons are valid client actions within Telegram limits',()=>{
  const id='idea-6d76b956-2140-44e1-8ebd-25e0f6c0a6d5';
  assert.ok(isTelegramClientAction('tc:c:'+id));assert.ok(isTelegramClientAction('tc:k:05:'+id));assert.ok(!isTelegramClientAction('tc:k:7:'+id));
});

import {createNotifications} from '../lib/notifications.mjs';
import {createTelegramClientMenu} from '../lib/telegram-client/menu.mjs';
import {serviceFixture} from './service-fixture.mjs';

test('idea updates reply to the first signal message and carry calculator/passport buttons',async t=>{
  const config={botToken:'123456:fixture_client_token_for_tests',botUsername:'OrbitaClientFixtureBot',webhookSecret:'fixture_client_webhook_secret',publicOrigin:'https://orbita.example.test'};
  const replies=[];let id=0;
  const f=await serviceFixture(({directory,accounts,ideas})=>createNotifications(directory,{accounts,ideas,config,
    clientMenu:{...createTelegramClientMenu({ideas,publicOrigin:config.publicOrigin}),isAction:isTelegramClientAction},
    fetchImpl:async(url,request)=>{const body=JSON.parse(request.body),messageId=++id;replies.push({method:url.split('/').at(-1),messageId,...body});return {ok:true,json:async()=>({ok:true,result:{message_id:messageId}})};}}));
  t.after(()=>f.close());
  const account=await f.register('pro@orbita.example.test');
  await f.accounts.transact(db=>{db.users.find(user=>user.id===account.data.user.id).subscriptions=[{plan:'pro',expiresAt:new Date(Date.now()+864e5).toISOString()}];});
  const {data:{deepLink}}=await f.request('/api/notifications/telegram/link',{method:'POST',cookie:account.cookie,body:{}});
  await f.request('/api/notifications/telegram/webhook',{method:'POST',headers:{Origin:'','X-Telegram-Bot-Api-Secret-Token':config.webhookSecret},
    body:{update_id:1,message:{message_id:1,chat:{id:777,type:'private'},from:{id:777,is_bot:false},text:'/start '+new URL(deepLink).searchParams.get('start')}}});
  assert.equal((await f.request('/api/notifications/preferences',{method:'PUT',cookie:account.cookie,body:{proSignals:true,levelChanges:true,ideaClosures:true,riskCapital:500000,watchTickers:['SBER']}})).status,200);
  await f.service.tick();
  const editor={id:'fixture-admin',role:'admin'};
  const {record}=await f.ideas.create(editor,{mode:'full',d:{ticker:'SBER',dir:'ЛОНГ',strategy:'Momentum RU',entry:100,stop:90,target:130,entryRule:'Вход.',cancelRule:'Стоп.'}});
  await f.service.tick();
  const first=replies.findLast(reply=>reply.method==='sendMessage'&&reply.text.includes('SBER'));
  assert.match(first.text,/Паспорт [0-9A-F]{4}-/);
  assert.ok(first.reply_markup.inline_keyboard.flat().some(button=>button.callback_data==='tc:c:'+record.id));
  const firstId=first.messageId;
  const revision=(await f.ideas.list(editor)).revision;
  await f.ideas.update(editor,record.id,{revision,action:'activate',note:'Вход по рынку'});
  await f.service.tick();
  const update=replies.findLast(reply=>reply.method==='sendMessage'&&reply.text.includes('вход выполнен'));
  assert.equal(update.reply_parameters?.message_id,firstId);
  const prefs=(await f.request('/api/notifications/preferences',{cookie:account.cookie})).data;
  assert.equal(prefs.settings.riskCapital,500000);assert.deepEqual(prefs.settings.watchTickers,['SBER']);
});
