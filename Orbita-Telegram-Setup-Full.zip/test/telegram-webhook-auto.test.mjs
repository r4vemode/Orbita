import test from 'node:test';
import assert from 'node:assert/strict';
import {chmod,mkdtemp,rm,writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {ensureTelegramWebhook,CLIENT_BOT_COMMANDS} from '../lib/telegram-webhook.mjs';
import {loadTelegramEnv} from '../lib/telegram-env.mjs';
import {createNotifications} from '../lib/notifications.mjs';
import {createTelegramClientMenu,isTelegramClientAction} from '../lib/telegram-client/menu.mjs';
import {serviceFixture} from './service-fixture.mjs';

const config={botToken:'123456:fixture_client_token_for_tests',botUsername:'OrbitaClientFixtureBot',webhookSecret:'fixture_client_webhook_secret',publicOrigin:'https://orbita.example.test'};
const fakeTelegram=(state)=>async(url,request)=>{
  const method=url.split('/').at(-1),body=JSON.parse(request.body||'{}');state.calls.push({method,body});
  const result=method==='getMe'?{is_bot:true,username:state.username||config.botUsername}:method==='getWebhookInfo'?{url:state.url,pending_update_count:0}:true;
  if(method==='setWebhook'&&state.acceptWebhook!==false){
    state.url=body.url;
    state.secret=body.secret_token;
  }
  return {ok:true,status:200,json:async()=>({ok:true,result})};
};

test('startup restores the secret and update types even when the URL already matches',async()=>{
  const state={calls:[],url:''},log=[];
  const first=await ensureTelegramWebhook(config,'/api/notifications/telegram/webhook',{commands:CLIENT_BOT_COMMANDS,fetchImpl:fakeTelegram(state),log:m=>log.push(m)});
  assert.equal(first.changed,true);
  const set=state.calls.find(call=>call.method==='setWebhook');
  assert.equal(set.body.url,'https://orbita.example.test/api/notifications/telegram/webhook');
  assert.equal(set.body.secret_token,config.webhookSecret);
  assert.ok(state.calls.some(call=>call.method==='setMyCommands'));
  assert.ok(log.every(line=>!line.includes(config.botToken)&&!line.includes(config.webhookSecret)));
  state.calls=[];
  state.secret='old_secret';
  const second=await ensureTelegramWebhook(config,'/api/notifications/telegram/webhook',{fetchImpl:fakeTelegram(state),log:()=>{}});
  assert.equal(second.ok,true);
  assert.equal(second.changed,false);
  assert.equal(state.secret,config.webhookSecret);
  const refreshed=state.calls.find(call=>call.method==='setWebhook').body;
  assert.deepEqual(refreshed.allowed_updates,['message','callback_query']);
  assert.equal(refreshed.drop_pending_updates,false);
});

test('startup does not report success when Telegram keeps a different webhook URL',async()=>{
  const state={calls:[],url:'https://previous.example.test/api/webhook',acceptWebhook:false};
  const result=await ensureTelegramWebhook(config,'/x',{fetchImpl:fakeTelegram(state),log:()=>{}});
  assert.equal(result.ok,false);
});

test('the private env file supplies Telegram settings without replacing hosting variables',async t=>{
  const directory=await mkdtemp(path.join(tmpdir(),'orbita-telegram-env-'));
  t.after(()=>rm(directory,{recursive:true,force:true}));
  const env={TELEGRAM_BOT_USERNAME:config.botUsername};
  await loadTelegramEnv(directory,env);
  const filename=path.join(directory,'.env.telegram');
  await writeFile(filename,'TELEGRAM_BOT_TOKEN='+config.botToken+'\nTELEGRAM_BOT_USERNAME=IgnoredBot\nPORT=9999\n',{mode:0o600});
  await loadTelegramEnv(directory,env);
  assert.deepEqual(env,{TELEGRAM_BOT_TOKEN:config.botToken,TELEGRAM_BOT_USERNAME:config.botUsername});
  if(process.platform!=='win32'){
    await chmod(filename,0o644);
    await assert.rejects(loadTelegramEnv(directory,{}),/600/);
  }
});

test('a token for another bot never moves its webhook',async()=>{
  const state={calls:[],url:'',username:'SomeoneElseBot'};
  const result=await ensureTelegramWebhook(config,'/x',{fetchImpl:fakeTelegram(state),log:()=>{}});
  assert.equal(result.ok,false);
  assert.ok(!state.calls.some(call=>call.method==='setWebhook'));
});

test('/start with any payload and plain text still answer with the menu',async t=>{
  const replies=[];
  const f=await serviceFixture(({directory,accounts,ideas})=>createNotifications(directory,{accounts,ideas,config,
    clientMenu:{...createTelegramClientMenu({ideas,publicOrigin:config.publicOrigin}),isAction:isTelegramClientAction},
    fetchImpl:async(url,request)=>{replies.push({method:url.split('/').at(-1),...JSON.parse(request.body)});return {ok:true,json:async()=>({ok:true,result:{}})};}}));
  t.after(()=>f.close());
  let id=0;
  const send=text=>f.request('/api/notifications/telegram/webhook',{method:'POST',body:{update_id:++id,message:{message_id:id,chat:{id:5001+id,type:'private'},from:{id:5001+id,is_bot:false},text}},headers:{Origin:'','X-Telegram-Bot-Api-Secret-Token':config.webhookSecret}});
  for(const text of ['/start landing','/start orb_broken','привет']){
    const before=replies.length;await send(text);
    assert.ok(replies.slice(before).some(reply=>reply.method==='sendMessage'&&/ORBITA/.test(reply.text)),text);
  }
});
