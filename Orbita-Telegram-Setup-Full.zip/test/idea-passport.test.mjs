import test from 'node:test';
import assert from 'node:assert/strict';
import {sealLastEvent,verifyPassport,passportView,fingerprint} from '../lib/idea-passport.mjs';

const record=()=>({id:'idea-1',d:{ticker:'SBER',dir:'ЛОНГ',strategy:'Momentum RU',state:'active',entry:300,stop:294,target:315},meta:{publishedAt:'2026-11-01T07:00:00.000Z',initial:{entry:300,stop:294,target:315},events:[]}});
const add=(r,type,after)=>{r.meta.events.push(['01.11.2026 · 10:00',type,'body',{id:'e'+r.meta.events.length,type,at:'2026-11-01T07:00:00.000Z',after,via:'WEB',actorId:'editor-secret'}]);sealLastEvent(r);};

test('passport chain verifies and detects retroactive edits',()=>{
  const r=record();add(r,'published',{entry:300,stop:294,target:315});add(r,'stop-change',{stop:300});
  const ok=verifyPassport(r);assert.equal(ok.status,'verified');assert.equal(ok.sealed,2);assert.match(ok.fingerprint,/^[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}$/);
  r.meta.events[0][3].after.stop=290;
  const bad=verifyPassport(r);assert.equal(bad.status,'broken');assert.equal(bad.brokenAt,0);
});

test('legacy events are shown but marked, and actor identity never leaves the server',()=>{
  const r=record();r.meta.events.push(['old','Опубликовано','',{id:'legacy',type:'published',at:'2026-10-01T00:00:00.000Z'}]);add(r,'activate',{entry:300});
  const view=passportView(r);assert.equal(view.chain.status,'partial');assert.equal(view.events[0].status,'legacy');
  assert.ok(!JSON.stringify(view).includes('editor-secret'));
  assert.equal(fingerprint(null),null);
});
