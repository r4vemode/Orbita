import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {computeReaction,withIndex,reactionStats} from '../lib/intel/reaction.mjs';
import {recurringEvents,normalizeCalendarEvent} from '../lib/intel/calendar.mjs';
import {buildGraph,propagate,correlation} from '../lib/intel/graph.mjs';
import {parseCandles,candlesPath} from '../lib/intel/moex.mjs';
import {createIntel} from '../lib/intel/service.mjs';

const MIN=60000,HOUR=3600000,DAY=86400000;
const t0=Date.parse('2026-11-24T08:00:00Z');// 11:00 MSK, inside the session
const series=(start,step,count,price)=>Array.from({length:count},(_,i)=>({begin:start+i*step,close:price(i)}));

test('reaction is measured from the first trade after the event and compared with IMOEX',()=>{
  const minute=series(t0-30*MIN,MIN,200,i=>i<30?100:110);
  const hourly=series(t0-2*DAY,HOUR,24*12,i=>i<48?100:120);
  const r=computeReaction({minute,hourly,t0,now:t0+9*DAY});
  assert.equal(r.base,100);assert.equal(r.horizons['5m'].changePct,10);assert.equal(r.horizons['1d'].changePct,20);assert.ok(r.horizons['1w']);
  const index=computeReaction({minute:series(t0-30*MIN,MIN,200,()=>50),hourly:series(t0-2*DAY,HOUR,24*12,i=>i<48?50:51),t0,now:t0+9*DAY});
  withIndex(r,index);assert.equal(r.horizons['1d'].indexPct,2);assert.equal(r.horizons['1d'].excessPct,18);
});

test('horizons wait for the exchange data delay',()=>{
  const r=computeReaction({minute:series(t0-30*MIN,MIN,60,()=>100),hourly:[],t0,now:t0+10*MIN});
  assert.deepEqual(Object.keys(r.horizons),[]);
});

test('reaction statistics aggregate excess moves and hit rate',()=>{
  const rows=[{eventType:'DIVIDEND',impact:'POSITIVE',horizons:{'1d':{changePct:3,excessPct:2}}},{eventType:'DIVIDEND',impact:'POSITIVE',horizons:{'1d':{changePct:-1,excessPct:-2}}}];
  const s=reactionStats(rows,{eventType:'DIVIDEND'});assert.equal(s.count,2);assert.equal(s.hitRate,50);assert.equal(s.averageExcessPct,0);
});

test('recurring calendar: weekly CPI on Wednesday 19:00 MSK, tax day, quarterly expiration',()=>{
  const events=recurringEvents(Date.parse('2026-12-01T00:00:00Z'),Date.parse('2026-12-31T00:00:00Z'));
  assert.ok(events.some(e=>e.id==='rec-cpi-2026-12-02'&&e.scheduledAt==='2026-12-02T16:00:00.000Z'));
  assert.ok(events.some(e=>e.id==='rec-tax-2026-12-28'));
  assert.ok(events.some(e=>e.id==='rec-exp-2026-12-17'));
  assert.throws(()=>normalizeCalendarEvent({title:'x',category:'nope',scheduledAt:'2026-12-01T10:00:00Z'}),/категорию/);
  const ok=normalizeCalendarEvent({title:'Решение по ставке',category:'rate',scheduledAt:'2026-12-18T10:30:00Z',importance:3,consensus:16,previous:16.5});
  assert.deepEqual(ok.nodes,['rate']);assert.ok(ok.instruments.includes('RGBI'));
});

test('event graph: rate hike reaches developers negatively and OFZ down',()=>{
  const graph=buildGraph();const chains=propagate(graph,'rate',1);
  const find=id=>chains.find(chain=>chain.to===id);
  assert.equal(find('ofz').effect,-1);assert.equal(find('developers').effect,-1);assert.equal(find('c:SMLT').effect,-1);assert.equal(find('exchange').effect,1);
  assert.ok(graph.nodes.some(node=>node.id==='c:SBER'));
  const a=Array.from({length:60},(_,i)=>({date:'d'+i,close:100+Math.sin(i)*5+i}));
  assert.equal(correlation(a,a).value,1);
});

test('MOEX candles parse and route to the right market',()=>{
  const rows=parseCandles({candles:{columns:['open','close','high','low','value','volume','begin','end'],data:[[1,2,3,0.5,10,5,'2026-11-24 10:00:00','2026-11-24 10:00:59']]}});
  assert.equal(rows[0].begin,Date.parse('2026-11-24T07:00:00Z'));
  assert.match(candlesPath('SiZ6'),/forts/);assert.match(candlesPath('CNYRUB_TOM'),/CETS/);assert.match(candlesPath('IMOEX'),/index/);
});

test('intel service tracks Radar reactions, serves calendar and brief',async t=>{
  const directory=await mkdtemp(path.join(tmpdir(),'intel-'));t.after(()=>rm(directory,{recursive:true,force:true}));
  let clock=t0+9*DAY;
  const client={candles:async(code,{interval})=>interval===1?series(t0-30*MIN,MIN,200,i=>code==='IMOEX'?50:(i<30?100:105)):series(t0-2*DAY,HOUR,24*12,i=>code==='IMOEX'?50:(i<48?100:110))};
  const radar={reactionCandidates:async()=>[{id:'r1',ticker:'SBER',eventType:'DIVIDEND',impact:'POSITIVE',importanceScore:9,headline:'Дивиденды',publishedAt:new Date(t0).toISOString()}],digestFor:async()=>[{ticker:'SBER',headline:'Дивиденды',importanceScore:9}]};
  const admin={id:'a',role:'admin'};
  const intel=await createIntel(directory,{accounts:{identify:async()=>admin},radar,ideas:{list:async()=>({records:[]})},env:{INTEL_MOEX:'true'},now:()=>clock,client});
  await intel.trackReactions();
  const reaction=intel.radarReaction('r1',{eventType:'DIVIDEND',impact:'POSITIVE'});
  assert.equal(reaction.change5m,5);assert.equal(reaction.change1d,10);assert.equal(reaction.excess1d,10);
  const brief=await intel.brief(admin,{settings:{watchTickers:['SBER']}});
  assert.equal(brief.radar[0].mine,true);
  assert.match(intel.briefText(brief),/Radar за ночь/);
  const view=await intel.graphView(admin);assert.ok(view.active.some(item=>item.node==='c:SBER'));
  await intel.close();
});
