import test from 'node:test';
import assert from 'node:assert/strict';
import {buildIssuerMatcher,createNewswireProvider,NEWSWIRE_FEEDS,newswireFeeds} from '../lib/radar/providers/newswire.mjs';
import {decodeBody} from '../lib/radar/providers/http.mjs';

test('newswire matcher names exactly one issuer, including inflected names',()=>{
  const match=buildIssuerMatcher();
  assert.equal(match('Совет директоров Сбербанка рекомендовал дивиденды')?.ticker,'SBER');
  assert.equal(match('«Газпром нефть» увеличила чистую прибыль по МСФО')?.ticker,'SIBN');
  assert.equal(match('Норильского никеля прибыль выросла')?.ticker,'GMKN');
  assert.equal(match('МТС Банк раскрыл результаты')?.ticker,'MBNK');
  assert.equal(match('ВТБ и МТС объявили о сделке'),null);
  assert.equal(match('Пик продаж пришёлся на ноябрь'),null);
});

test('newswire provider keeps only material single-issuer headlines from allowed hosts',async()=>{
  const at=new Date(Date.now()-3600e3).toUTCString().replace('GMT','+0000');
  const rss=`<?xml version="1.0" encoding="utf-8"?><rss><channel>
    <item><title>Совет директоров «Северстали» рекомендовал дивиденды</title><link>https://www.interfax.ru/business/1</link><pubDate>${at}</pubDate></item>
    <item><title>Погода в Москве</title><link>https://www.interfax.ru/moscow/2</link><pubDate>${at}</pubDate></item>
    <item><title>Лукойл увеличил выручку по МСФО</title><link>https://evil.example/3</link><pubDate>${at}</pubDate></item>
  </channel></rss>`;
  const provider=createNewswireProvider({...NEWSWIRE_FEEDS[0],enabled:true,requestImpl:async()=>({body:rss,contentType:'application/rss+xml'})});
  const {events}=await provider.fetchEvents();
  assert.equal(events.length,1);
  assert.equal(events[0].ticker,'CHMF');
  assert.equal(events[0].sourceType,'OTHER');
  assert.equal(events[0].isDemo,false);
});

test('custom newswire feeds come from configuration',()=>{
  const feeds=newswireFeeds({RADAR_NEWSWIRE_FEEDS:'Финам|https://www.finam.ru/rss.xml'});
  assert.equal(feeds.at(-1).name,'Финам');
  assert.deepEqual(feeds.at(-1).hosts,['www.finam.ru']);
});

test('windows-1251 feeds are decoded',()=>{
  assert.equal(decodeBody(Buffer.from([0xcf,0xf0,0xe8,0xe2,0xe5,0xf2]),'text/xml; charset=windows-1251'),'Привет');
});
