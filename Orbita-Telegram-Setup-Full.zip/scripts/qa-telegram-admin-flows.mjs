import assert from 'node:assert/strict';
import path from 'node:path';
import {createIdeas} from '../lib/ideas.mjs';

// This suite uses a caller-owned synthetic beta and mocked Bot configuration.
// It never connects to Telegram or reads an operator's account database.
export async function runTelegramAdminFlows({session,browser,record,outputDir}){
 const base=session.base,accounts=Object.fromEntries(session.accounts.map(account=>[account.role,account])),contexts=[],screenshots=[],errors=[],check=record||(async(_title,work)=>work());
 const code='orbadmin_'+'A'.repeat(32),botUsername='OrbitaFixtureBot';
 let editor,guest,view,state,linkCalls=0,preferenceCalls=[],unlinks=0,linkResponse;
 async function login(context,role){const account=accounts[role],response=await context.request.post(base+'/api/login',{headers:{Origin:base},data:{email:account.email,password:account.password}});assert.equal(response.status(),200);}
 async function context(role){const result=await browser.newContext({viewport:{width:1440,height:1000},locale:'ru-RU',timezoneId:'Europe/Moscow',reducedMotion:'reduce'});contexts.push(result);await result.route('https://fonts.googleapis.com/**',route=>route.abort());await result.route('https://fonts.gstatic.com/**',route=>route.abort());if(role)await login(result,role);return result;}
 async function request(ctx,route,{method='GET',data,status=200}={}){const response=await ctx.request.fetch(base+route,{method,maxRedirects:0,headers:{Origin:base},...(data===undefined?{}:{data})});assert.equal(response.status(),status,route);return response.headers()['content-type']?.includes('application/json')?response.json():null;}
 async function opened(){await view.goto(base+'/telegram-admin.html');await view.waitForFunction(()=>!document.getElementById('telegramWorkspace').hidden&&!document.getElementById('telegramRefresh').disabled&&document.getElementById('telegramConnectionState').textContent.trim().length>0);}
 const unlinked=()=>({enabled:true,configured:true,botUsername,linked:false,binding:null,preferences:{instantPublish:false,strategy:'Momentum RU'}});
 const linked=()=>({...unlinked(),linked:true,binding:{telegramUserId:'123456789',linkedAt:new Date().toISOString()}});
 const freshLink=()=>({code,expiresAt:new Date(Date.now()+600000).toISOString(),botUrl:'https://t.me/'+botUsername});
 async function screenshot(name){if(!outputDir)return;await view.screenshot({path:path.join(outputDir,name),fullPage:true});screenshots.push(name);}
 try{
  await check('Telegram редакции: гости и клиенты закрыты, выключенный бот не притворяется подключённым',async()=>{
   editor=await context('admin');guest=await context();
   for(const route of ['/telegram-admin.html','/%74elegram-admin.html']){await request(guest,route,{status:303});await request(editor,route);}
   for(const route of ['/assets/telegram-admin.js','/assets/%74elegram-admin.js','/api/admin/telegram'])await request(guest,route,{status:401});
   for(const role of ['free','pro','exclusive']){const client=await context(role);await request(client,'/telegram-admin.html',{status:303});await request(client,'/assets/telegram-admin.js',{status:403});await request(client,'/api/admin/telegram',{status:403});}
   const actual=await request(editor,'/api/admin/telegram');assert.equal(actual.enabled,false);assert.equal(actual.configured,false);assert.equal(actual.linked,false);assert.equal(actual.preferences.instantPublish,false);assert.ok(!JSON.stringify(actual).includes('botToken'));await request(editor,'/api/admin/telegram/link',{method:'POST',data:{},status:503});
   view=await editor.newPage();view.on('pageerror',cause=>errors.push(cause.name));await opened();assert.equal(await view.locator('#telegramLink').isDisabled(),true);assert.equal(await view.locator('#telegramCodePanel').isHidden(),true);assert.equal(await view.locator('#telegramBroadcastPassword').isDisabled(),true);assert.match(await view.locator('#telegramConnectionState').innerText(),/выключен/);
  });
  await check('Telegram редакции: одноразовая команда показана только в текущей вкладке и скрывается при уходе',async()=>{
   state=unlinked();linkResponse=freshLink();
   await view.route('**/api/admin/telegram',route=>route.fulfill({status:200,json:state}));
   await view.route('**/api/admin/telegram/preferences',route=>{preferenceCalls.push(route.request().postDataJSON());state={...state,preferences:{...state.preferences,...route.request().postDataJSON()}};return route.fulfill({status:200,json:{preferences:state.preferences}});});
   await view.route('**/api/admin/telegram/link',route=>{if(route.request().method()==='DELETE'){unlinks++;state=unlinked();return route.fulfill({status:200,json:{ok:true}});}linkCalls++;return route.fulfill({status:201,json:linkResponse});});
   await opened();assert.equal(await view.locator('#telegramInstant').count(),0);await view.locator('#telegramLink').click();await view.waitForSelector('#telegramCodePanel:not([hidden])');assert.equal(await view.locator('#telegramCode').innerText(),'/connect '+code);assert.equal(await view.locator('#telegramBotUrl').getAttribute('href'),'https://t.me/'+botUsername);
   assert.equal(await view.evaluate(value=>Object.values(localStorage).concat(Object.values(sessionStorage)).some(item=>item.includes(value)),code),false);
   await view.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'));});assert.equal(await view.locator('#telegramCode').textContent(),'');assert.equal(await view.locator('#telegramCodePanel').isHidden(),true);
   await view.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,value:false});document.dispatchEvent(new Event('visibilitychange'));});await view.waitForFunction(()=>document.getElementById('telegramWorkspace').style.visibility!=='hidden');assert.equal(await view.locator('#telegramCode').textContent(),'');
  });
  await check('Telegram редакции: стратегия сохраняется, подтверждение публикаций и рассылок разделено',async()=>{
   const attempts=[];
   await view.route('**/api/admin/telegram/*-authorization',route=>{
    attempts.push({type:route.request().url().split('/').at(-1),data:route.request().postDataJSON()});
    return route.fulfill({status:201,json:{expiresAt:new Date(Date.now()+600000).toISOString()}});
   });
   state=linked();await opened();await view.locator('#telegramStrategy').selectOption('Orbita Exclusive');await view.locator('#telegramSave').click();
   await view.waitForFunction(()=>document.getElementById('telegramPreferencesMessage').textContent.includes('сохранены'));
   assert.deepEqual(preferenceCalls,[{strategy:'Orbita Exclusive'}]);
   for(const [value,label] of [['publication','Публикации разрешены'],['broadcast','Рассылка разрешена']]){
    await view.locator('#telegramBroadcastPassword').fill('fixture-password');await view.locator('#telegramBroadcastCode').fill('123456');
    await view.locator('#broadcast button[value="'+value+'"]').click();await view.waitForFunction(label=>document.getElementById('telegramBroadcastStatus').textContent.includes(label),label);
    assert.equal(await view.locator('#telegramBroadcastPassword').inputValue(),'');assert.equal(await view.locator('#telegramBroadcastCode').inputValue(),'');
   }
   assert.deepEqual(attempts.map(call=>call.type),['publication-authorization','broadcast-authorization']);
  });
  await check('Telegram редакции: неверные ссылки и просроченные коды отклоняются, прежнюю привязку можно отключить при выключенном боте',async()=>{
   state=unlinked();await opened();for(const invalid of [{...freshLink(),botUrl:'https://outside.example/'+botUsername},{...freshLink(),expiresAt:new Date(Date.now()-1000).toISOString()}]){linkResponse=invalid;await view.locator('#telegramLink').click();await view.waitForFunction(()=>!document.getElementById('telegramLink').disabled);assert.equal(await view.locator('#telegramCodePanel').isHidden(),true);assert.equal(await view.locator('#telegramBotUrl').getAttribute('href'),null);assert.match(await view.locator('#telegramStatus').innerText(),/Не удалось подтвердить/);}
   state={...linked(),enabled:false,configured:false};await opened();assert.equal(await view.locator('#telegramLink').isDisabled(),true);assert.equal(await view.locator('#telegramUnlink').isDisabled(),false);view.once('dialog',dialog=>dialog.accept());await view.locator('#telegramUnlink').click();await view.waitForFunction(()=>document.getElementById('telegramConnectionState').dataset.linked==='false');assert.equal(unlinks,1);assert.equal(await view.locator('#telegramBinding').textContent(),'');
   for(const width of [320,390,768,1440]){await view.setViewportSize({width,height:1000});assert.ok(await view.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'Telegram admin overflow '+width);}await view.setViewportSize({width:390,height:1000});await screenshot('telegram-admin-390.png');await view.setViewportSize({width:1440,height:1000});await screenshot('telegram-admin-1440.png');
  });
  await check('Telegram редакции: сигнал из общего сервиса открывается по прямой ссылке и сопровождается через веб с неизменной исходной историей',async()=>{
   const actor=(await request(editor,'/api/me')).user,ideas=await createIdeas(session.directory),created=await ideas.create(actor,{mode:'full',d:{ticker:'SBER',name:'Сбербанк · учебный сигнал Telegram',market:'stocks',dir:'ЛОНГ',strategy:'Momentum RU',title:'Учебный сигнал из Telegram',summary:'Учебный сценарий общей редакции.',thesis:'',horizon:'1–5 дней',entry:100,stop:95,target:110,entryRule:'Вход только после подтверждения автором.',cancelRule:'Отмена до входа; стоп 95, цель 110.'}},{createdVia:'TELEGRAM',telegramChatId:'123456789',telegramMessageId:1,operationId:'fixture-browser-bot',authorize:async()=>(await request(editor,'/api/me')).user});
   const id=created.record.id,chartUrl='https://www.tradingview.com/chart/fixture-orbita',owned=async()=>(await request(editor,'/api/admin/ideas')).records.find(item=>item.id===id);
   await view.goto(base+'/admin.html?idea='+encodeURIComponent(id));await view.waitForSelector('#adminMain:not([hidden])');await view.waitForSelector('#ideaList [data-id="'+id+'"][aria-pressed=true]');assert.match(await view.locator('#selectedIdea').innerText(),/Источник:\s*Telegram/);assert.match(await view.locator('#selectedIdea').innerText(),/SBER/);assert.equal((await owned()).d.state,'waiting');
   async function save(action,note,fill=async()=>{}){await view.locator('#eventAction').selectOption(action);await fill();await view.locator('#eventNote').fill(note);const response=view.waitForResponse(value=>value.request().method()==='POST'&&new URL(value.url()).pathname==='/api/admin/ideas/'+id+'/events');await view.locator('#saveEvent').click();assert.equal((await response).status(),200);await view.waitForFunction(value=>document.getElementById('eventHistory').textContent.includes(value)&&!document.getElementById('saveEvent').disabled,note);}
   await view.locator('#eventAction').selectOption('description');assert.equal(await view.locator('#descriptionTitle').inputValue(),'Учебный сигнал из Telegram');assert.equal(await view.locator('#descriptionName').inputValue(),'Сбербанк · учебный сигнал Telegram');
   await save('description','Учебное уточнение описания из веб-редакции.',async()=>{await view.locator('#descriptionTitle').fill('Дополненный сценарий Telegram');await view.locator('#descriptionSummary').fill('Обновлённое учебное описание без изменения входа.');await view.locator('#descriptionThesis').fill('Учебный разбор, добавленный после быстрой публикации.');await view.locator('#descriptionChart').fill(chartUrl);});
   assert.equal((await owned()).d.title,'Дополненный сценарий Telegram');assert.equal((await owned()).meta.initial.title,'Учебный сигнал из Telegram');assert.equal((await owned()).d.chartUrl,chartUrl);assert.ok(!(await owned()).meta.initial.chartUrl);
   await view.locator('#eventAction').selectOption('terms-change');assert.equal(await view.locator('#levelEntry').inputValue(),'100');assert.equal(await view.locator('#levelEntryRule').inputValue(),'Вход только после подтверждения автором.');
   await save('terms-change','Учебное уточнение уровня до подтверждения входа.',async()=>{await view.locator('#levelEntry').fill('101');await view.locator('#levelEntryRule').fill('Вход 101 после отдельного подтверждения автором.');});assert.equal((await owned()).d.entry,101);assert.equal((await owned()).meta.initial.entry,100);
   await save('target-change','Учебное изменение цели через общую редакцию.',async()=>{await view.locator('#exitPrice').fill('115');});assert.equal((await owned()).d.target,115);
   await save('activate','Учебное подтверждение входа после уточнения условий.');const active=await owned();assert.equal(active.d.state,'active');assert.equal(active.meta.initial.entry,100);assert.equal(active.meta.initial.target,110);assert.equal(active.meta.events[0][3].via,'TELEGRAM');assert.ok(active.meta.events.slice(1).every(event=>event[3].via==='WEB'));assert.ok(!await view.locator('#eventAction option[value="terms-change"]').count());assert.equal(active.createdVia,'TELEGRAM');
   let remoteChartRequests=0;await view.route('https://www.tradingview.com/**',route=>{remoteChartRequests++;return route.abort();});await view.goto(base+'/app.html?idea='+encodeURIComponent(id));await view.waitForSelector('#signalStage.detail-mode');await view.waitForSelector('#ideaDetail:not([hidden]) a[data-author-chart]');const chart=view.locator('#ideaDetail a[data-author-chart]');assert.equal(await chart.getAttribute('href'),chartUrl);assert.equal(await chart.getAttribute('target'),'_blank');assert.match(await chart.getAttribute('rel'),/noopener/);assert.match(await chart.getAttribute('rel'),/noreferrer/);await view.setViewportSize({width:390,height:1000});assert.ok(await view.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));assert.equal(remoteChartRequests,0);assert.deepEqual(errors,[]);
  });
  await check('Telegram редакции: поздний ответ с кодом не раскрывается после смены аккаунта',async()=>{
   state=unlinked();await opened();let resolveStarted,release;const started=new Promise(resolve=>{resolveStarted=resolve;}),held=new Promise(resolve=>{release=resolve;});
   await view.route('**/api/admin/telegram/link',async route=>{resolveStarted();await held;await route.fulfill({status:201,json:freshLink()}).catch(()=>{});},{times:1});
   await view.evaluate(()=>window.addEventListener('beforeunload',()=>sessionStorage.setItem('qa.telegram.cleared',JSON.stringify({code:document.getElementById('telegramCode')?.textContent.length||0,binding:document.getElementById('telegramBinding')?.textContent.length||0,hidden:document.getElementById('telegramWorkspace')?.hidden})),{once:true}));
   await view.locator('#telegramLink').click();await started;await login(editor,'free');release();await view.waitForURL(url=>url.pathname==='/subscriptions.html');assert.deepEqual(await view.evaluate(()=>JSON.parse(sessionStorage.getItem('qa.telegram.cleared'))),{code:0,binding:0,hidden:true});assert.ok(!(await view.content()).includes(code));await request(editor,'/api/admin/telegram',{status:403});assert.deepEqual(errors,[]);assert.ok(linkCalls>=3);
  });
  return {screenshots};
 }finally{await Promise.allSettled(contexts.map(context=>context.close()));}
}
