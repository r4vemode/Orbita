/* ORBITA · Главная. Morning brief first; subscribers see everything,
   free accounts see the real calendar and track record plus locked previews. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = (value, digits = 2) => Number.isFinite(value) ? value.toLocaleString('ru-RU', { maximumFractionDigits: digits }) : '—';
  const pct = (value, digits = 2) => Number.isFinite(value) ? (value > 0 ? '+' : value < 0 ? '−' : '') + Math.abs(value).toLocaleString('ru-RU', { maximumFractionDigits: digits }) + '%' : '—';
  const tone = value => value > 0 ? 'up' : value < 0 ? 'down' : '';
  const msk = (value, options) => new Intl.DateTimeFormat('ru-RU', { timeZone: 'Europe/Moscow', ...options }).format(new Date(value));
  const when = value => Number.isFinite(Date.parse(value)) ? msk(value, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '';
  const day = value => Number.isFinite(Date.parse(value)) ? msk(value, { day: 'numeric', month: 'short' }) : '';
  const calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const get = async path => {
    const response = await fetch(path, { credentials: 'same-origin', cache: 'no-store' });
    if (response.status === 401) { location.replace('/account.html?next=' + encodeURIComponent('/home.html')); throw Error('auth'); }
    return response.ok ? response.json() : null;
  };
  const dirBadge = dir => dir === 'ШОРТ' ? '<span class="dir short">SHORT</span>' : '<span class="dir long">LONG</span>';
  const STATES = { announced: 'Анонс', waiting: 'Ждёт входа', active: 'В сделке' };
  const IMPACT = { POSITIVE: ['Позитив', 'up'], NEGATIVE: ['Негатив', 'down'], MIXED: ['Неоднозначно', ''], NEUTRAL: ['Нейтрально', ''] };
  const GHOST = { radar: ['SBER · совет директоров рекомендовал дивиденды', 'GMKN · операционные результаты за квартал', 'YDEX · выкуп акций у миноритариев'], ideas: ['SBER LONG — в сделке', 'SiZ6 SHORT — ждёт входа', 'GAZP LONG — анонс'], chains: ['Ключевая ставка ↑ → ОФЗ ↓, девелоперы ↓', 'Нефть ↑ → рубль ↑ → экспортёры ↓'] };

  function countUp(node, target, format) {
    if (!Number.isFinite(target)) return;
    if (calm) { node.textContent = format(target); return; }
    const start = performance.now(), span = 1100;
    const step = now => { const t = Math.min(1, (now - start) / span), eased = 1 - Math.pow(1 - t, 3); node.textContent = format(target * eased); if (t < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  }
  function locked(target, { title, text, plan = 'pro', rows = 4, count }) {
    const ghost = Array.from({ length: rows }, (_, i) => `<div class="ghost-row"><i style="width:${38 + (i * 17) % 30}%"></i><i style="width:${18 + (i * 11) % 14}%"></i><i style="width:${12 + (i * 7) % 10}%"></i></div>`).join('');
    target.innerHTML = `<div class="home-locked"><div class="ghost" aria-hidden="true">${ghost}</div><div class="lock-copy"><span class="lock-icon" aria-hidden="true">◈</span><b>${esc(title)}</b><p>${esc(text)}${count ? ` <strong>${esc(count)}</strong>` : ''}</p><a class="home-button primary" href="/subscriptions.html?plan=${plan}">Открыть в ${plan.toUpperCase()} →</a></div></div>`;
  }
  const empty = (target, text, link) => { target.innerHTML = `<p class="home-muted">${esc(text)}</p>${link ? `<a class="home-button" href="${link[1]}">${esc(link[0])}</a>` : ''}`; };
  const plural = (n, one, few, many) => n % 10 === 1 && n % 100 !== 11 ? one : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? few : many;

  function paintPlan(user, dashboard) {
    const plans = user.access?.activePlans || [], node = $('homePlan');
    if (user.access?.isAdmin) { node.innerHTML = '<span class="home-plan-badge admin">Редакция</span><a href="/admin.html">Открыть редакцию →</a>'; return; }
    if (!plans.length) { node.innerHTML = '<span class="home-plan-badge free">Бесплатный доступ</span><a class="home-button primary" href="/subscriptions.html?plan=pro">Открыть PRO →</a>'; return; }
    const active = (dashboard?.subscriptions || []).filter(s => s.accessActive);
    node.innerHTML = active.map(s => `<span class="home-plan-badge ${esc(s.plan)}">${esc(s.plan.toUpperCase())}</span><small>до ${esc(day(s.expiresAt))}${s.daysRemaining <= 3 ? ' · <a href="' + esc(s.renewUrl) + '">продлить</a>' : ''}</small>`).join('');
  }

  function closedTrades(results, tiers, free) {
    return (results || []).filter(r => r.state === 'closed' && Number.isFinite(r.pct) && (free || tiers.includes(r.tier))).sort((a, b) => Date.parse(a.closedAt) - Date.parse(b.closedAt));
  }
  function paintStats(closed) {
    if (!closed.length) return;
    const wins = closed.filter(r => r.pct > 0).length, since = Date.now() - 30 * 864e5, month = closed.filter(r => Date.parse(r.closedAt) >= since), monthSum = month.reduce((a, r) => a + r.pct, 0);
    countUp($('kpiWin'), wins / closed.length * 100, v => Math.round(v) + '%'); $('kpiWinNote').textContent = `${wins} из ${closed.length}`;
    countUp($('kpiTrades'), closed.length, v => Math.round(v).toLocaleString('ru-RU'));
    if (month.length) { countUp($('kpiMonth'), monthSum, v => pct(v, 1)); $('kpiMonth').className = tone(monthSum); $('kpiMonthNote').textContent = `${month.length}\u00a0${plural(month.length, 'сделка', 'сделки', 'сделок')}`; }
    const first = Date.parse(closed[0].enteredAt || closed[0].closedAt);
    if (Number.isFinite(first)) $('kpiTradesNote').textContent = 'с\u00a0' + msk(first, { day: 'numeric', month: 'long' }).replace(' ', '\u00a0');
  }
  function paintTicker(closed) {
    const last = closed.slice(-24).reverse();
    if (!last.length) { document.querySelector('.hx-ticker').hidden = true; return; }
    const item = r => `<span class="tk"><b>${esc(r.ticker)}</b>${r.dir === 'ШОРТ' ? 'SHORT' : 'LONG'}<em class="${tone(r.pct)}">${pct(r.pct)}</em><small>${esc(day(r.closedAt))}</small></span>`;
    const html = last.map(item).join('');
    $('hxTrack').innerHTML = html + html; // seamless loop
  }
  function paintCurve(closed) {
    const svg = $('curveSvg');
    if (closed.length < 3) { svg.innerHTML = ''; $('curveTotal').textContent = '—'; return; }
    let sum = 0; const points = closed.map(r => (sum += r.pct, { t: Date.parse(r.closedAt), v: sum }));
    const t0 = points[0].t, t1 = points.at(-1).t || t0 + 1, min = Math.min(0, ...points.map(p => p.v)), max = Math.max(...points.map(p => p.v), 1);
    const x = t => 8 + (t - t0) / Math.max(1, t1 - t0) * 584, y = v => 200 - (v - min) / (max - min || 1) * 180;
    const line = points.map((p, i) => (i ? 'L' : 'M') + x(p.t).toFixed(1) + ',' + y(p.v).toFixed(1)).join(' ');
    svg.innerHTML = `<defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fb2ff" stop-opacity=".45"/><stop offset="1" stop-color="#7fb2ff" stop-opacity="0"/></linearGradient></defs>
      <line x1="0" x2="600" y1="${y(0)}" y2="${y(0)}" class="curve-zero"/>
      <path d="${line} L${x(points.at(-1).t)},210 L${x(t0)},210 Z" fill="url(#cg)" class="curve-area"/>
      <path d="${line}" class="curve-line" pathLength="1"/>
      <circle cx="${x(points.at(-1).t)}" cy="${y(points.at(-1).v)}" r="4.5" class="curve-dot"/>`;
    countUp($('curveTotal'), sum, v => pct(v, 1)); $('curveTotal').className = 'curve-total ' + tone(sum);
    $('curveNote').textContent = `${closed.length} ${plural(closed.length, 'сделка', 'сделки', 'сделок')} с ${msk(t0, { day: 'numeric', month: 'long' })}: сумма результатов в процентах на сделку, без плеча и комиссий. Архив сценариев и опубликованных идей — не фактическая доходность клиента и не гарантия.`;
  }

  function paintBrief(brief, free) {
    if (!brief) { $('briefCalendar').innerHTML = '<li class="home-muted">Сводка временно недоступна.</li>'; return; }
    $('briefTime').textContent = msk(brief.generatedAt, { weekday: 'long', day: 'numeric', month: 'long' });
    const cal = brief.calendar.slice(0, 5);
    $('briefCalendar').innerHTML = cal.length ? cal.map(e => `<li><span class="bt">${esc(e.time)}</span><span class="bi">${'●'.repeat(e.importance)}<i>${'●'.repeat(3 - e.importance)}</i></span><span>${esc(e.title)}${Number.isFinite(e.consensus) ? ` <small>консенсус ${num(e.consensus)}${esc(e.unit || '')}</small>` : ''}</span></li>`).join('') : '<li class="home-muted">Значимых событий сегодня нет — спокойный день для техники.</li>';
    if (free) {
      for (const [id, key] of [['briefRadar', 'radar'], ['briefIdeas', 'ideas'], ['briefChains', 'chains']]) $(id).innerHTML = GHOST[key].map(text => `<li class="ghost-text">${esc(text)}</li>`).join('');
      document.querySelectorAll('.brief-block[data-paid]').forEach(block => block.classList.add('is-blurred'));
      $('briefLock').hidden = false; return;
    }
    $('briefRadar').innerHTML = brief.radar.length ? brief.radar.map(r => `<li><span class="bt">${r.mine ? '★ ' : ''}${esc(r.ticker)}</span><span>${esc(r.headline)}</span><span class="score">${num(r.importance, 1)}</span></li>`).join('') : '<li class="home-muted">За ночь важных событий не было.</li>';
    $('briefIdeas').innerHTML = brief.ideas.length ? brief.ideas.slice(0, 5).map(i => `<li><span class="bt">${i.mine ? '★ ' : ''}${esc(i.ticker)}</span>${dirBadge(i.dir)}<span>${esc(STATES[i.state] || '')}${Number.isFinite(i.entry) ? ` · ${num(i.entry, 8)} / <span class="down">${num(i.stop, 8)}</span> / <span class="up">${num(i.target, 8)}</span>` : ''}</span></li>`).join('') : '<li class="home-muted">Открытых идей нет — новые придут в Telegram.</li>';
    $('briefChains').innerHTML = brief.chains.length ? brief.chains.map(c => `<li><span>${esc(c.trigger)}</span><span class="chain">${c.effects.map(e => `<em class="${e.effect > 0 ? 'up' : e.effect < 0 ? 'down' : ''}">${esc(e.to)} ${e.effect > 0 ? '↑' : e.effect < 0 ? '↓' : '↕'}</em>`).join('')}</span></li>`).join('') + '<li><a href="/graph.html">Открыть граф влияния →</a></li>' : '<li class="home-muted">Сегодня нет событий, запускающих цепочки. <a href="/graph.html">Исследовать граф →</a></li>';
  }

  function paintIdeas(data, openCount) {
    if (!data) {
      locked($('ideasBody'), { title: 'Открытые идеи — в подписке', text: 'Тикер, направление, вход, стоп и цели в момент публикации.' + (openCount > 0 ? ' Сейчас в работе:' : ''), count: openCount > 0 ? openCount + ' ' + plural(openCount, 'идея', 'идеи', 'идей') : '' });
      $('ideasCount').textContent = openCount > 0 ? openCount : '—'; return;
    }
    const open = (data.records || []).filter(r => r.published && ['announced', 'waiting', 'active'].includes(r.d?.state)).sort((a, b) => Date.parse(b.meta?.updatedAt || b.meta?.publishedAt) - Date.parse(a.meta?.updatedAt || a.meta?.publishedAt));
    $('ideasCount').textContent = open.length;
    if (!open.length) { empty($('ideasBody'), 'Сейчас открытых идей нет. Новые появятся в «Стратегиях» и придут в Telegram.', ['Настроить уведомления', '/notifications.html']); return; }
    $('ideasBody').innerHTML = `<div class="home-table" role="table" aria-label="Открытые идеи"><div class="tr th" role="row"><span role="columnheader">Инструмент</span><span role="columnheader">Вход</span><span role="columnheader">Стоп</span><span role="columnheader">Цель</span><span role="columnheader">Статус</span></div>${open.slice(0, 6).map(r => { const d = r.d; return `<a class="tr" role="row" href="/app.html?idea=${encodeURIComponent(r.id)}"><span role="cell"><b>${esc(d.ticker)}</b>${dirBadge(d.dir)}</span><span role="cell">${num(d.entry, 8)}</span><span role="cell" class="down">${num(d.stop, 8)}</span><span role="cell" class="up">${num(d.target, 8)}</span><span role="cell" class="state ${esc(d.state)}">${esc(STATES[d.state] || d.status || '')}</span></a>`; }).join('')}</div>`;
  }
  function paintRadar(dashboard, important) {
    const radar = dashboard?.radar;
    if (!radar?.available) { locked($('radarBody'), { title: 'Radar — по подписке PRO', text: 'Дивиденды, отчётность, байбэки и решения советов директоров с оценкой значимости и реакцией рынка после события.' }); return; }
    const items = (important?.events?.length ? important.events : radar.items || []).slice(0, 5);
    if (!items.length) { empty($('radarBody'), 'Важных событий пока нет.'); return; }
    $('radarBody').innerHTML = `<ul class="home-list radar">${items.map(e => { const [label, cls] = IMPACT[e.impact] || ['', '']; return `<li><a href="/radar.html?event=${encodeURIComponent(e.id)}"><div class="row-main"><b>${esc(e.ticker)}</b><span class="home-muted small">${esc(e.companyName || '')} · ${esc(when(e.publishedAt))}${e.isDemo ? ' · учебное' : ''}</span></div><p>${esc(e.headline)}</p></a><span class="row-side">${Number.isFinite(e.importanceScore) ? `<span class="score">${num(e.importanceScore, 1)}</span>` : ''}${label ? `<span class="impact ${cls}">${label}</span>` : ''}</span></li>`; }).join('')}</ul>`;
  }
  function paintClosed(closed) {
    const rows = closed.slice(-6).reverse();
    if (!rows.length) { empty($('closedBody'), 'Закрытых сделок пока нет.'); return; }
    $('closedBody').innerHTML = `<ul class="home-list">${rows.map(r => `<li><div class="row-main"><b>${esc(r.ticker)}</b>${dirBadge(r.dir)}<span class="home-muted small">${esc(day(r.closedAt))}</span></div><span class="row-value ${tone(r.pct)}">${pct(r.pct)}</span></li>`).join('')}</ul>`;
  }
  function paintMarkets(markets) {
    if (!markets) { locked($('marketsBody'), { title: 'Рынки — по подписке', text: 'Фьючерсы MOEX, открытый интерес и позиции физлиц против юрлиц.', rows: 3 }); return; }
    const list = (markets.instruments || []).filter(i => Number.isFinite(i.quote?.last)).sort((a, b) => Math.abs(b.quote.changePct || 0) - Math.abs(a.quote.changePct || 0)).slice(0, 5);
    if (!list.length) { empty($('marketsBody'), markets.mode === 'off' ? 'Источник данных биржи сейчас отключён.' : 'Данные биржи ещё загружаются.', ['Открыть каталог', '/markets.html']); return; }
    $('marketsBody').innerHTML = `<ul class="home-list">${list.map(i => `<li><div class="row-main"><b>${esc(i.name)}</b></div><span class="row-value">${num(i.quote.last, 4)} <small class="${tone(i.quote.changePct)}">${pct(i.quote.changePct)}</small></span></li>`).join('')}</ul>`;
  }
  function paintMine(dashboard) {
    if (!dashboard) { empty($('mineBody'), 'Кабинет временно не загрузился.', ['Открыть кабинет', '/dashboard.html']); return; }
    const p = dashboard.positions?.total ?? 0, u = dashboard.updates?.total ?? 0;
    $('mineBody').innerHTML = `<div class="mine-stats"><a href="/dashboard.html#positions"><b>${p}</b><span>мои позиции</span></a><a href="/dashboard.html#updates"><b>${u}</b><span>обновления</span></a></div>${p ? '' : '<p class="home-muted small">Сохраните цену входа в идее — здесь появится личный результат.</p>'}`;
  }

  async function start() {
    const me = await get('/api/me'), user = me?.user;
    if (!user) { location.replace('/account.html?next=' + encodeURIComponent('/home.html')); return; }
    const tiers = user.access?.isAdmin ? ['pro', 'exclusive'] : user.access?.tiers || [];
    const free = !user.access?.isAdmin && !user.access?.hasSubscription;
    const hour = Number(msk(Date.now(), { hour: 'numeric', hourCycle: 'h23' }));
    $('homeDate').textContent = 'ORBITA / ' + msk(Date.now(), { weekday: 'long', day: 'numeric', month: 'long' }).toUpperCase();
    $('homeTitle').innerHTML = (hour < 5 ? 'Доброй ночи.' : hour < 12 ? 'Доброе утро.' : hour < 18 ? 'Добрый день.' : 'Добрый вечер.') + ' <em>Рынок уже движется.</em>';
    if (free) $('homeIntro').textContent = 'Сводка дня и история стратегий уже здесь. Сигналы с уровнями, Radar и граф влияния откроются с PRO.';
    document.documentElement.classList.toggle('home-free', free);
    $('homeUpsell').hidden = !free;
    document.querySelectorAll('#homeLinks [data-paid]').forEach(link => { if (free) { link.classList.add('is-locked'); link.href = '/subscriptions.html?plan=pro'; link.insertAdjacentHTML('beforeend', '<em>PRO</em>'); } });
    const settle = promise => promise.catch(error => { if (error.message === 'auth') throw error; return null; });
    const [dashboard, scenarios, publicResults, brief, ideas, important, markets] = await Promise.all([
      settle(get('/api/dashboard')), settle(get('/api/public/history-scenarios')), settle(get('/api/public/results')), settle(get('/api/intel/brief')),
      free ? null : settle(get('/api/ideas')), free ? null : settle(get('/api/radar/important')), free ? null : settle(get('/api/markets'))
    ]);
    const closed = closedTrades([...(scenarios?.results || []), ...(publicResults?.results || [])], tiers, free);
    paintPlan(user, dashboard); paintStats(closed); paintTicker(closed); paintCurve(closed);
    paintBrief(brief?.brief, free); paintIdeas(ideas, publicResults?.open); paintRadar(dashboard, important);
    paintClosed(closed); paintMarkets(markets); paintMine(dashboard);
    const pro = dashboard?.subscriptions?.find(s => s.plan === 'pro');
    if (pro?.price) $('proPrice').textContent = `PRO · ${pro.price.toLocaleString('ru-RU')} ₽ за ${pro.days} дней`;
    $('home').setAttribute('aria-busy', 'false');
  }
  start().catch(error => { if (error.message !== 'auth') { const intro = $('homeIntro'); if (intro) intro.textContent = 'Не удалось загрузить сводку. Обновите страницу.'; } });
})();
