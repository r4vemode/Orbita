orbita-symbols.woff2 — subset of DejaVu Sans (arrows U+2190–21FF, geometric shapes U+25A0–25FF, ⌘, ✓, ✕, ✗).
DejaVu fonts are distributed under the Bitstream Vera Fonts license (free redistribution and modification;
modified versions must not use the name "Bitstream Vera"/"DejaVu"). https://dejavu-fonts.github.io/License.html
Used so arrow icons render as text (not emoji or blank boxes) in iOS/macOS Safari and every other browser.
