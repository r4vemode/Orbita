/* ORBITA · Паспорт идеи. Renders the history and re-verifies the hash chain in the browser. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = value => Number.isFinite(value) ? value.toLocaleString('ru-RU', { maximumFractionDigits: 8 }) : '—';
  const pct = value => Number.isFinite(value) ? (value > 0 ? '+' : value < 0 ? '−' : '') + Math.abs(value).toLocaleString('ru-RU', { maximumFractionDigits: 2 }) + '%' : '—';
  const when = value => Number.isFinite(Date.parse(value)) ? new Intl.DateTimeFormat('ru-RU', { timeZone: 'Europe/Moscow', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(value)) : '';
  const print = hash => typeof hash === 'string' ? hash.slice(0, 12).toUpperCase().replace(/(.{4})(?=.)/g, '$1-') : '—';
  const ICON = { published: '◉', levels: '◫', activate: '▶', 'stop-change': '⛔', 'target-change': '◎', 'terms-change': '✎', 'partial-close': '◐', 'early-close': '■', manual: '■', target: '✓', stop: '✕', cancel: '○', description: '✎', 'strategy-change': '⇄' };
  const LABEL = { entry: 'Вход', stop: 'Стоп', target: 'Цель', exit: 'Выход', remainingPct: 'Остаток', finalResultPct: 'Итог', realizedPct: 'Зафиксировано' };

  // Same canonical form as lib/idea-passport.mjs.
  function canonical(value) {
    if (value === undefined) return 'null';
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
    return '{' + Object.keys(value).filter(key => value[key] !== undefined).sort().map(key => JSON.stringify(key) + ':' + canonical(value[key])).join(',') + '}';
  }
  async function sha256(text) {
    const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2, '0')).join('');
  }
  async function verify(passport) {
    if (!crypto?.subtle) return null;
    let prev = passport.proof.genesis, sealed = 0;
    for (const step of passport.proof.events) {
      if (!step) continue;
      sealed++;
      const content = { record: passport.id, stamp: step.stamp, title: step.title, body: step.body, type: step.type, at: step.at, note: step.note, before: step.before, after: step.after, closure: step.closure, via: step.via, id: step.id };
      if (step.prev !== prev || await sha256(prev + '|' + canonical(content)) !== step.hash) return { ok: false, sealed };
      prev = step.hash;
    }
    return { ok: true, sealed, head: sealed ? prev : null };
  }

  function diff(before, after) {
    if (!after) return '';
    const keys = ['entry', 'stop', 'target', 'exit', 'remainingPct', 'finalResultPct'].filter(key => after[key] !== undefined && after[key] !== null && (!before || before[key] !== after[key]));
    if (!keys.length) return '';
    return '<div class="pp-diff">' + keys.map(key => {
      const format = /Pct$/.test(key) ? (key === 'remainingPct' ? v => num(v) + '%' : pct) : num;
      const old = before && before[key] !== undefined && before[key] !== null ? `<s>${format(before[key])}</s> → ` : '';
      return `<span><small>${LABEL[key] || key}</small>${old}<b>${format(after[key])}</b></span>`;
    }).join('') + '</div>';
  }

  function render(p, check) {
    const dir = p.dir === 'ШОРТ' ? 'SHORT' : 'LONG';
    $('ppTitle').innerHTML = `${esc(p.ticker)} <span class="pp-dir ${dir.toLowerCase()}">${dir}</span>`;
    $('ppSub').textContent = [p.name && p.name !== p.ticker ? p.name : '', p.strategy, p.publishedAt ? 'опубликована ' + when(p.publishedAt) : ''].filter(Boolean).join(' · ');
    $('ppState').textContent = p.erroneous ? 'Ошибочная публикация' : p.outcome || p.status || '';
    $('ppState').className = 'pp-state ' + (p.state || '');
    document.title = `ORBITA — паспорт ${p.ticker} ${dir}`;

    const seal = $('ppSeal'); seal.hidden = false;
    const chain = p.chain;
    let state = chain.status;
    if (check && !check.ok) state = 'broken';
    const variants = {
      verified: ['✓', 'История не изменялась', `Все события (${chain.sealed}) связаны цепочкой хэшей${check?.ok ? ' — ваш браузер пересчитал её и подтвердил' : ''}.`],
      partial: ['◐', 'История частично защищена', `Ранние события (${chain.legacy}) записаны до появления паспорта, последующие (${chain.sealed}) связаны цепочкой${check?.ok ? ' и проверены вашим браузером' : ''}.`],
      legacy: ['○', 'Идея опубликована до появления паспорта', 'Хронология показана как есть, но цепочкой хэшей не защищена.'],
      broken: ['!', 'Цепочка нарушена', 'Одно из событий не совпадает со своим отпечатком. Сообщите в поддержку — мы проверим запись.']
    };
    const titles = variants[state] || variants.legacy;
    $('ppSealMark').textContent = titles[0]; seal.dataset.state = state;
    $('ppSealTitle').textContent = titles[1]; $('ppSealText').textContent = titles[2];
    $('ppFirst').textContent = chain.publishedFingerprint || '—';
    $('ppHead').textContent = chain.fingerprint || '—';

    if (p.initial || p.current) {
      $('ppLevels').hidden = false;
      const rows = [['Вход', 'entry'], ['Стоп', 'stop'], ['Цель', 'target']];
      const extra = p.current?.targets?.length ? [['Доп. цели', 'targets']] : [];
      $('ppGrid').innerHTML = [...rows, ...extra].map(([label, key]) => {
        const a = key === 'targets' ? (p.initial?.targets || []).map(num).join(', ') || '—' : num(p.initial?.[key]);
        const b = key === 'targets' ? (p.current?.targets || []).map(num).join(', ') || '—' : num(p.current?.[key]);
        const changed = a !== b && a !== '—';
        return `<div class="pp-level${changed ? ' changed' : ''}"><small>${label}</small><span class="was">${a}</span><span class="now">${changed ? '→ ' + b : 'без изменений'}</span></div>`;
      }).join('') + (Number.isFinite(p.current?.finalResultPct) || Number.isFinite(p.current?.exit) ? `<div class="pp-level result"><small>Итог</small><span class="now ${p.current.finalResultPct > 0 ? 'up' : p.current.finalResultPct < 0 ? 'down' : ''}">${Number.isFinite(p.current.finalResultPct) ? pct(p.current.finalResultPct) : 'выход ' + num(p.current.exit)}</span></div>` : '');
    }

    $('ppTimelineWrap').hidden = false;
    $('ppTimeline').innerHTML = p.events.map(e => `<li class="pp-event ${esc(e.type)} ${e.status === 'broken' ? 'is-broken' : ''}">
      <span class="pp-dot" aria-hidden="true">${ICON[e.type] || '•'}</span>
      <div class="pp-event-body"><div class="pp-event-head"><b>${esc(e.title)}</b><time datetime="${esc(e.at)}">${esc(when(e.at) || e.stamp)}</time></div>
      ${e.body ? `<p>${esc(e.body)}</p>` : ''}${diff(e.before, e.after)}
      <small class="pp-hash">${e.hash ? 'отпечаток ' + print(e.hash) + (e.status === 'ok' ? ' · ✓' : e.status === 'broken' ? ' · не совпадает' : '') : 'до введения паспорта'}</small></div></li>`).join('');
  }

  async function start() {
    const id = new URLSearchParams(location.search).get('id');
    if (!id) throw Error('Не указана идея. Откройте паспорт из карточки идеи.');
    const response = await fetch('/api/passport?id=' + encodeURIComponent(id), { credentials: 'same-origin', cache: 'no-store' });
    const data = await response.json().catch(() => ({}));
    if (response.status === 401) { location.replace('/account.html?next=' + encodeURIComponent(location.pathname + location.search)); return; }
    if (!response.ok) throw Error(data.error || 'Паспорт недоступен.');
    const check = await verify(data.passport).catch(() => null);
    render(data.passport, check);
  }
  $('ppCopy').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(location.href); $('ppCopy').textContent = 'Ссылка скопирована ✓'; } catch { $('ppCopy').textContent = location.href; }
  });
  start().catch(error => { $('ppError').hidden = false; $('ppError').textContent = error.message; $('ppTitle').textContent = 'Паспорт недоступен'; })
    .finally(() => $('passport').setAttribute('aria-busy', 'false'));
})();
