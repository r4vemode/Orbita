(async () => {
  await window.ORBITA_LESSONS_READY;
  const lessons = window.ORBITA_LESSONS;
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const account = await OrbitaAccess.current();
  if (!account) { location.replace('account.html?next=%2Flearn.html'); return; }
  let invalidated=false;
  const session=OrbitaMemberSession.watch(account,next=>{
    invalidated=true;lessons.splice(0);window.ORBITA_LESSONS=[];closeReader(false);$('articleBody').replaceChildren();$('lessons').replaceChildren();document.querySelector('main').hidden=true;
    location.replace(!next?'account.html?next=%2Flearn.html':!next.access?.hasSubscription?'subscriptions.html':location.pathname+location.search);
  });
  if(!await session.check())return;
  const key = 'orbita.learning.v2.' + account.id;
  let read = new Set(), category = 'Все темы', selected = 0, articleOrigin = null;
  try {
    const saved = JSON.parse(localStorage.getItem(key) || '[]');
    if (Array.isArray(saved)) read = new Set(saved.filter(id => lessons.some(l => l.id === id)));
  } catch {}
  const sources = {
    short: ['Механика коротких продаж · Investor.gov', 'https://www.investor.gov/introduction-investing/investing-basics/how-stock-markets-work/stock-purchases-and-sales-long-and'],
    orders: ['Типы заявок · Investor.gov', 'https://www.investor.gov/introduction-investing/investing-basics/how-stock-markets-work/types-orders'],
    leverage: ['Маржинальные счета · Investor.gov', 'https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-29']
  };
  $('categories').innerHTML = ['Все темы', ...new Set(lessons.map(l => l.category))].map(c => `<button aria-pressed="${c === category}" data-category="${esc(c)}">${esc(c)}</button>`).join('');
  $('progressBar').max = Math.max(1, lessons.length);

  function render() {
    if(invalidated)return;
    const query = $('search').value.trim().toLocaleLowerCase('ru');
    const rows = lessons.filter(l => (category === 'Все темы' || l.category === category) && [l.title, l.intro, ...l.sections.map(s => s.title + ' ' + s.text)].join(' ').toLocaleLowerCase('ru').includes(query));
    $('lessons').innerHTML = rows.map(l => `<button class="lesson-card" data-lesson="${esc(l.id)}"><span class="lesson-meta"><span>${esc(l.category)}</span><span>${String(lessons.indexOf(l) + 1).padStart(2, '0')} / ${String(lessons.length).padStart(2, '0')}</span></span><h2>${esc(l.title)}</h2><p>${esc(l.intro)}</p><span class="lesson-bottom"><span>${read.has(l.id) ? '✓ Прочитано' : 'Открыть материал'}</span><span aria-hidden="true">↗</span></span></button>`).join('');
    $('empty').hidden = !!rows.length;
    $('empty').textContent = lessons.length ? 'Ничего не найдено. Попробуйте другой запрос или раздел.' : 'Автор готовит материалы для вашей подписки. Тренажёр уже доступен выше.';
    $('resultCount').textContent = `Тем: ${rows.length}`;
    $('progress').textContent = `${read.size} из ${lessons.length} тем прочитано · на этом устройстве`;
    $('progressBar').value = read.size;
  }

  function setArticleUrl(id) {
    const url = new URL(location.href);
    if (id) url.searchParams.set('lesson', id);
    else url.searchParams.delete('lesson');
    url.hash = '';
    history.replaceState(null, '', url.pathname + url.search + url.hash);
  }

  const isReading = () => !$('article').hidden;
  const words = text => String(text).trim().split(/\s+/).filter(Boolean).length;
  let tocObserver = null;
  function closeReader(restoreFocus = true) {
    if (!isReading()) return;
    $('article').hidden = true; $('article').removeAttribute('open');
    document.querySelector('main.academy')?.classList.remove('is-reading');
    tocObserver?.disconnect(); tocObserver = null;
    if (!restoreFocus) return;
    const cards = [...$('lessons').querySelectorAll('[data-lesson]')];
    const target = cards.find(card => card.dataset.lesson === articleOrigin) || cards[0] || $('search');
    articleOrigin = null;
    requestAnimationFrame(() => { target.scrollIntoView({ block: 'center' }); target.focus({ preventScroll: true }); });
  }
  function leaveReader() {
    if (history.state?.orbitaLesson) history.back();
    else { setArticleUrl(null); closeReader(); }
  }

  function open(id, update = true) {
    if(invalidated)return;
    const index = lessons.findIndex(l => l.id === id);
    if (index < 0) { if (id) $('resultCount').textContent = 'Этот материал снят с публикации или недоступен по вашей подписке. Выберите другую тему.'; closeReader(false); return; }
    selected = index;
    const lesson = lessons[index];
    if (!isReading()) articleOrigin = document.activeElement?.closest('[data-lesson]')?.dataset.lesson || id;
    $('articleCategory').textContent = lesson.category + (lesson.access === 'exclusive' ? ' · EXCLUSIVE' : '') + ' · ' + String(index + 1).padStart(2, '0') + ' из ' + String(lessons.length).padStart(2, '0');
    $('readerHead').innerHTML = `<h1 id="articleTitle">${esc(lesson.title)}</h1><p class="article-lead">${esc(lesson.intro)}</p>`;
    $('articleBody').innerHTML = lesson.sections.map((s, i) => `<section id="lesson-part-${i + 1}"><span class="reader-step" aria-hidden="true">${String(i + 1).padStart(2, '0')}</span><h2>${esc(s.title)}</h2><p>${esc(s.text)}</p></section>`).join('') + (sources[id] ? `<p class="article-source"><a href="${sources[id][1]}" target="_blank" rel="noopener noreferrer">${sources[id][0]} ↗</a></p>` : '') + (lesson.kind === 'article' ? `<p class="article-source"><a href="/article.html?id=${encodeURIComponent(id)}">Открыть статью и источники ↗</a></p>` : '');
    $('readerToc').innerHTML = lesson.sections.map((s, i) => `<li><a href="#lesson-part-${i + 1}" data-part="${i + 1}"><span>${String(i + 1).padStart(2, '0')}</span>${esc(s.title)}</a></li>`).join('');
    const minutes = Math.max(1, Math.round(words([lesson.intro, ...lesson.sections.map(s => s.title + ' ' + s.text)].join(' ')) / 170));
    $('readerMeta').textContent = `≈ ${minutes} мин чтения` + (read.has(id) ? ' · прочитано' : '');
    $('markRead').textContent = read.has(id) ? '✓ Прочитано' : 'Отметить прочитанным';
    $('markRead').disabled = read.has(id);
    $('prevArticle').disabled = index === 0;
    $('nextArticle').disabled = index === lessons.length - 1;
    $('nextArticle').textContent = index === lessons.length - 1 ? 'Это последняя тема' : 'Следующая тема →';
    $('article').hidden = false; $('article').setAttribute('open', '');
    document.querySelector('main.academy')?.classList.add('is-reading');
    $('article').classList.remove('is-entering'); void $('article').offsetWidth; $('article').classList.add('is-entering');
    window.scrollTo({ top: 0, behavior: 'instant' in document.documentElement.style ? 'instant' : 'auto' });
    $('closeArticle').focus({ preventScroll: true });
    tocObserver?.disconnect();
    if ('IntersectionObserver' in window) {
      tocObserver = new IntersectionObserver(entries => {
        for (const entry of entries) if (entry.isIntersecting) {
          const part = entry.target.id.split('-').pop();
          $('readerToc').querySelectorAll('a').forEach(a => a.toggleAttribute('aria-current', a.dataset.part === part));
        }
      }, { rootMargin: '-30% 0px -60% 0px' });
      $('articleBody').querySelectorAll('section[id]').forEach(section => tocObserver.observe(section));
    }
    updateProgress();
    if (update) {
      const url = new URL(location.href); url.searchParams.set('lesson', id); url.hash = '';
      if (history.state?.orbitaLesson) history.replaceState({ orbitaLesson: id }, '', url.pathname + url.search);
      else history.pushState({ orbitaLesson: id }, '', url.pathname + url.search);
    }
  }
  function updateProgress() {
    if (!isReading()) return;
    const body = $('articleBody').getBoundingClientRect(), total = body.height - innerHeight * .6;
    const value = total > 0 ? Math.min(1, Math.max(0, -body.top / total)) : 1;
    $('readerProgress').style.transform = `scaleX(${value.toFixed(3)})`;
  }
  window.addEventListener('scroll', () => requestAnimationFrame(updateProgress), { passive: true });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && isReading() && !event.target.closest?.('input,textarea,select')) leaveReader(); });
  $('readerToc').onclick = event => {
    const link = event.target.closest('a[data-part]'); if (!link) return;
    event.preventDefault();
    document.getElementById('lesson-part-' + link.dataset.part)?.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
  };
  $('prevArticle').onclick = () => { if (selected > 0) open(lessons[selected - 1].id); };

  $('lessons').onclick = event => {
    const button = event.target.closest('[data-lesson]');
    if (button) open(button.dataset.lesson);
  };
  $('categories').onclick = event => {
    const button = event.target.closest('[data-category]');
    if (!button) return;
    category = button.dataset.category;
    document.querySelectorAll('[data-category]').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
    render();
  };
  $('search').oninput = render;
  $('closeArticle').onclick = leaveReader;
  $('markRead').onclick = () => {
    read.add(lessons[selected].id);
    try { localStorage.setItem(key, JSON.stringify([...read])); } catch {}
    render();
    $('markRead').textContent = '✓ Прочитано';
    $('markRead').disabled = true;
  };
  $('nextArticle').onclick = () => {
    if (selected + 1 < lessons.length) open(lessons[selected + 1].id);
  };
  const openFromLocation = () => { const id = new URLSearchParams(location.search).get('lesson') || location.hash.slice(1); if (id) open(id, false); else closeReader(); };
  window.addEventListener('hashchange', openFromLocation);
  window.addEventListener('popstate', openFromLocation);
  render();
  openFromLocation();
})().catch(error=>{const node=document.getElementById('resultCount');if(node){node.textContent=error.message+' ';const retry=document.createElement('button');retry.type='button';retry.textContent='Повторить загрузку';retry.onclick=()=>location.reload();node.append(retry);}const progress=document.getElementById('progress');if(progress)progress.textContent='Материалы пока не загружены';});
