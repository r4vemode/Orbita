/* ORBITA · Event Graph — concentric "orbits": factors, sectors, companies. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const NS = 'http://www.w3.org/2000/svg', SIZE = 1000, C = SIZE / 2, RINGS = { factor: 150, market: 150, sector: 285, company: 430 };
  let data, byId, pos = new Map(), selected = null, direction = 1, outgoing = new Map();

  function layout() {
    const sectors = data.nodes.filter(n => n.layer === 'sector');
    const members = new Map(sectors.map(s => [s.id, data.edges.filter(e => e.from === s.id && e.kind === 'member').map(e => e.to)]));
    const total = [...members.values()].reduce((sum, list) => sum + Math.max(1, list.length), 0);
    let angle = -Math.PI / 2;
    for (const sector of sectors) {
      const span = Math.max(1, members.get(sector.id).length) / total * Math.PI * 2;
      const mid = angle + span / 2;
      pos.set(sector.id, { a: mid, r: RINGS.sector });
      members.get(sector.id).forEach((id, i, list) => { if (!pos.has(id)) pos.set(id, { a: angle + span * (i + .5) / list.length, r: RINGS.company }); });
      angle += span;
    }
    // Inner ring ordered by the mean angle of what each factor influences, to keep lines short.
    const inner = data.nodes.filter(n => n.layer === 'factor' || n.layer === 'market');
    const meanAngle = id => { const targets = data.edges.filter(e => e.from === id && pos.has(e.to)).map(e => pos.get(e.to).a); if (!targets.length) return null; const x = targets.reduce((s, a) => s + Math.cos(a), 0), y = targets.reduce((s, a) => s + Math.sin(a), 0); return Math.atan2(y, x); };
    const scored = inner.map((n, i) => ({ n, a: meanAngle(n.id) ?? (-Math.PI / 2 + i / inner.length * Math.PI * 2) }));
    scored.sort((p, q) => ((p.a + 2.5 * Math.PI) % (2 * Math.PI)) - ((q.a + 2.5 * Math.PI) % (2 * Math.PI)));
    scored.forEach(({ n }, i) => pos.set(n.id, { a: -Math.PI / 2 + (i + .5) / scored.length * Math.PI * 2, r: n.layer === 'market' ? RINGS.market + 18 : RINGS.factor - 18 * (i % 2) }));
    for (const [id, p] of pos) { p.x = C + Math.cos(p.a) * p.r; p.y = C + Math.sin(p.a) * p.r; }
  }
  const el = (name, attrs = {}, parent) => { const node = document.createElementNS(NS, name); for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v); parent?.append(node); return node; };

  function draw() {
    const svg = $('graphSvg'); svg.setAttribute('viewBox', `0 0 ${SIZE} ${SIZE}`); svg.replaceChildren();
    const defs = el('defs', {}, svg);
    const glow = el('radialGradient', { id: 'gcore' }, defs); el('stop', { offset: '0', 'stop-color': '#a8c9ff', 'stop-opacity': '.35' }, glow); el('stop', { offset: '1', 'stop-color': '#a8c9ff', 'stop-opacity': '0' }, glow);
    for (const r of [RINGS.factor, RINGS.sector, RINGS.company]) el('circle', { cx: C, cy: C, r, class: 'g-orbit' }, svg);
    el('circle', { cx: C, cy: C, r: 70, fill: 'url(#gcore)' }, svg);
    const core = el('text', { x: C, y: C + 5, class: 'g-core', 'text-anchor': 'middle' }, svg); core.textContent = 'РЫНОК';
    const edges = el('g', { class: 'g-edges' }, svg);
    for (const edge of data.edges) {
      const a = pos.get(edge.from), b = pos.get(edge.to); if (!a || !b) continue;
      const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2, k = .25;
      el('path', { d: `M${a.x},${a.y} Q${mx + (C - mx) * k},${my + (C - my) * k} ${b.x},${b.y}`, class: 'g-edge ' + edge.kind, 'data-from': edge.from, 'data-to': edge.to }, edges);
    }
    const nodes = el('g', { class: 'g-nodes' }, svg);
    const activeIds = new Set(data.active.map(a => a.node));
    for (const node of data.nodes) {
      const p = pos.get(node.id); if (!p) continue;
      const g = el('g', { class: `g-node ${node.layer}${activeIds.has(node.id) ? ' is-active' : ''}`, transform: `translate(${p.x},${p.y})`, tabindex: '0', role: 'button', 'aria-label': node.label, 'data-id': node.id }, nodes);
      const r = node.layer === 'company' ? 5 : node.layer === 'sector' ? 8 : 10;
      if (activeIds.has(node.id)) el('circle', { r: r + 9, class: 'g-pulse' }, g);
      el('circle', { r, class: 'g-dot' }, g);
      const outside = node.layer === 'company', cos = Math.cos(p.a), sin = Math.sin(p.a);
      const label = el('text', { class: 'g-label', x: outside ? cos * 12 : 0, y: outside ? sin * 12 + 3 : r + 14, 'text-anchor': outside ? (cos > .2 ? 'start' : cos < -.2 ? 'end' : 'middle') : 'middle' }, g);
      label.textContent = outside ? node.ticker : node.label;
    }
    svg.addEventListener('click', event => { const id = event.target.closest('.g-node')?.dataset.id; if (id) select(id, 1); });
    svg.addEventListener('keydown', event => { if (event.key !== 'Enter' && event.key !== ' ') return; const id = event.target.closest('.g-node')?.dataset.id; if (id) { event.preventDefault(); select(id, 1); } });
  }

  // Client-side propagation (same rules as lib/intel/graph.mjs) so any node can be explored.
  function propagate(start, dir) {
    const chains = [], walk = (id, path, sign, power, seen) => {
      if (path.length >= 3) return;
      for (const edge of outgoing.get(id) || []) {
        if (seen.has(edge.to) || edge.sign === 0) continue;
        const next = [...path, edge], effect = sign * edge.sign, strength = Math.min(power, edge.strength);
        chains.push({ to: edge.to, effect, strength, path: next });
        walk(edge.to, next, effect, strength, new Set([...seen, edge.to]));
      }
    };
    walk(start, [], dir, 3, new Set([start]));
    const best = new Map();
    for (const chain of chains) { const current = best.get(chain.to); if (!current || chain.strength > current.strength || chain.strength === current.strength && chain.path.length < current.path.length) best.set(chain.to, chain); }
    return [...best.values()].sort((a, b) => b.strength - a.strength || a.path.length - b.path.length);
  }

  function select(id, dir, context = null) {
    selected = id; direction = dir;
    const chains = propagate(id, dir), reach = new Map(chains.map(c => [c.to, c.effect])), used = new Set(chains.flatMap(c => c.path.map(e => e.from + '>' + e.to)));
    document.querySelectorAll('.g-node').forEach(node => { const nid = node.dataset.id; node.classList.toggle('is-selected', nid === id); node.classList.toggle('is-up', reach.get(nid) > 0); node.classList.toggle('is-down', reach.get(nid) < 0); node.classList.toggle('is-dim', nid !== id && !reach.has(nid)); });
    document.querySelectorAll('.g-edge').forEach(edge => { const key = edge.dataset.from + '>' + edge.dataset.to, on = used.has(key); edge.classList.toggle('is-on', on); edge.classList.toggle('is-dim', !on); const effect = reach.get(edge.dataset.to); edge.classList.toggle('up', on && effect > 0); edge.classList.toggle('down', on && effect < 0); });
    const node = byId.get(id), label = n => byId.get(n)?.label || n;
    const corr = edge => { const c = data.edges.find(e => e.from === edge.from && e.to === edge.to)?.correlation; return c ? ` <span class="g-corr" title="Корреляция дневных изменений за ${c.days} дней">ρ ${c.value.toLocaleString('ru-RU')}</span>` : ''; };
    const companies = chains.filter(c => byId.get(c.to)?.layer === 'company');
    const others = chains.filter(c => byId.get(c.to)?.layer !== 'company');
    const chainHtml = c => `<li class="${c.effect > 0 ? 'up' : 'down'}"><b>${esc(label(c.to))} ${c.effect > 0 ? '↑' : '↓'}</b><span class="g-path">${c.path.map(e => `${esc(label(e.from))} ${e.sign > 0 ? '→' : '⇢'} ${esc(label(e.to))}`).join(' · ')}</span><small>${esc(c.path.at(-1).why)}${corr(c.path.at(-1))}</small></li>`;
    $('graphPanel').innerHTML = `<p class="intel-eyebrow">${esc({ factor: 'ФАКТОР', market: 'РЫНОК', sector: 'СЕКТОР', company: 'КОМПАНИЯ' }[node.layer])}</p><h2>${esc(node.label)}</h2><p class="intel-muted">${esc(node.about || '')}</p>
      ${context ? `<p class="g-context">${esc(context)}</p>` : ''}
      <div class="g-dir" role="group" aria-label="Сценарий"><button type="button" data-dir="1" aria-pressed="${dir > 0}">Если растёт ↑</button><button type="button" data-dir="-1" aria-pressed="${dir < 0}">Если падает ↓</button></div>
      ${chains.length ? `<h3>Кого затрагивает (${chains.length})</h3><ul class="g-chains">${others.slice(0, 12).map(chainHtml).join('')}</ul>${companies.length ? `<h3>Компании</h3><div class="g-tags">${companies.slice(0, 40).map(c => `<a href="/radar.html" class="${c.effect > 0 ? 'up' : 'down'}" title="${esc(c.path.map(e => label(e.to)).join(' → '))}">${esc(byId.get(c.to).ticker)} ${c.effect > 0 ? '↑' : '↓'}</a>`).join('')}</div>` : ''}` : '<p class="intel-muted">Исходящих связей нет — этот узел сам испытывает влияние.</p>'}
      <p class="g-disclaimer">Связи — гипотезы, а не гарантированные последствия; рынок может уже учитывать событие.</p>`;
    $('graphPanel').querySelectorAll('[data-dir]').forEach(b => b.addEventListener('click', () => select(id, Number(b.dataset.dir), context)));
    history.replaceState(null, '', '/graph.html?node=' + encodeURIComponent(id));
  }

  function renderActive() {
    const box = $('graphActive');
    if (!data.active.length) { box.innerHTML = '<p class="intel-muted">Сегодня нет событий, которые запускают цепочки. Исследуйте граф — например, «Ключевая ставка ЦБ» или «Нефть Brent».</p>'; return; }
    box.innerHTML = '<h2>Сейчас в движении</h2><div class="g-active">' + data.active.map((a, i) => `<button type="button" data-active="${i}" class="${a.mixed ? '' : a.direction > 0 ? 'up' : 'down'}"><small>${esc(byId.get(a.node)?.label || a.node)} · ${a.source.type === 'radar' ? 'Radar' : 'Календарь'}</small><b>${esc(a.label)}</b><span>${a.chains.length} цепочек</span></button>`).join('') + '</div>';
    box.querySelectorAll('[data-active]').forEach(b => b.addEventListener('click', () => { const a = data.active[Number(b.dataset.active)]; select(a.node, a.direction, a.label); $('graphPanel').scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }));
  }

  async function start() {
    const response = await fetch('/api/intel/graph', { credentials: 'same-origin', cache: 'no-store' });
    if (response.status === 401) { location.replace('/account.html?next=%2Fgraph.html'); return; }
    const body = await response.json().catch(() => ({}));
    if (response.status === 403) { $('graphStatus').innerHTML = 'Граф влияния открывается по подписке. <a href="/subscriptions.html?plan=pro">Подключить PRO →</a>'; $('graphPage').classList.add('is-locked'); return; }
    if (!response.ok) throw Error(body.error || 'Граф недоступен.');
    data = body; byId = new Map(data.nodes.map(n => [n.id, n]));
    for (const edge of data.edges) { if (!outgoing.has(edge.from)) outgoing.set(edge.from, []); outgoing.get(edge.from).push(edge); }
    layout(); draw(); renderActive();
    $('graphNote').textContent = data.note + (data.correlationsAt ? ' Корреляции обновлены ' + new Date(data.correlationsAt).toLocaleDateString('ru-RU') + '.' : '');
    $('graphStatus').textContent = '';
    const requested = new URLSearchParams(location.search).get('node');
    if (requested && byId.has(requested)) select(requested, 1);
    else if (data.active[0]) select(data.active[0].node, data.active[0].direction, data.active[0].label);
    $('graphPage').setAttribute('aria-busy', 'false');
  }
  start().catch(error => { $('graphStatus').textContent = error.message; });
})();
