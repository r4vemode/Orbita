/* ORBITA · Экономический календарь (macro + corporate dates from Radar). */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = value => Number.isFinite(value) ? value.toLocaleString('ru-RU', { maximumFractionDigits: 3 }) : '—';
  const pct = value => Number.isFinite(value) ? (value > 0 ? '+' : value < 0 ? '−' : '') + Math.abs(value).toLocaleString('ru-RU', { maximumFractionDigits: 2 }) + '%' : '—';
  const tz = { timeZone: 'Europe/Moscow' };
  const dayKey = ms => new Date(ms + 3 * 3600000).toISOString().slice(0, 10);
  const dayTitle = key => { const date = new Date(key + 'T12:00:00Z'), today = dayKey(Date.now()), tomorrow = dayKey(Date.now() + 864e5); const label = new Intl.DateTimeFormat('ru-RU', { ...tz, weekday: 'long', day: 'numeric', month: 'long' }).format(date); return key === today ? 'Сегодня · ' + label : key === tomorrow ? 'Завтра · ' + label : label[0].toUpperCase() + label.slice(1); };
  const clock = iso => new Intl.DateTimeFormat('ru-RU', { ...tz, hour: '2-digit', minute: '2-digit' }).format(new Date(iso));
  const RADAR_TYPES = { DIVIDEND: 'Дивиденды', EARNINGS: 'Отчётность', BOARD_MEETING: 'Совет директоров', BOND_COUPON: 'Купон', BOND_OFFER: 'Оферта', BOND_REDEMPTION: 'Погашение', GUIDANCE: 'Прогноз', OTHER: 'Корпоративное' };
  let range = 'week', events = [], corporate = [], categories = {}, filter = new Set(), canEdit = false, editing = null;

  function bounds() {
    const now = Date.now(), start = Date.parse(dayKey(now) + 'T00:00:00+03:00');
    if (range === 'today') return [start, start + 864e5 - 1];
    if (range === 'month') return [start, start + 31 * 864e5];
    if (range === 'past') return [start - 30 * 864e5, now];
    return [start, start + 8 * 864e5];
  }
  async function get(url) {
    const response = await fetch(url, { credentials: 'same-origin', cache: 'no-store' });
    if (response.status === 401) { location.replace('/account.html?next=%2Fcalendar.html'); throw Error('auth'); }
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw Object.assign(Error(data.error || 'Календарь недоступен.'), { status: response.status });
    return data;
  }
  async function load() {
    const [from, to] = bounds();
    $('calStatus').textContent = 'Загружаем календарь…';
    const data = await get(`/api/intel/calendar?from=${new Date(from).toISOString()}&to=${new Date(to).toISOString()}`);
    events = data.events; categories = data.categories; canEdit = data.canEdit;
    try { corporate = (await get('/api/radar/calendar')).events || []; } catch { corporate = []; }
    $('calAdd').hidden = !canEdit;
    if (!$('calCategories').children.length) {
      $('calCategories').innerHTML = Object.entries(categories).map(([key, label]) => `<button type="button" data-category="${esc(key)}" aria-pressed="false">${esc(label)}</button>`).join('') + '<button type="button" data-category="corporate" aria-pressed="false">Компании</button>';
      $('calCategory').innerHTML = Object.entries(categories).map(([key, label]) => `<option value="${esc(key)}">${esc(label)}</option>`).join('');
    }
    render();
  }
  function rows() {
    const [from, to] = bounds(), important = $('calImportant').checked;
    const macro = events.map(e => ({ kind: 'macro', at: Date.parse(e.scheduledAt), e }));
    const corp = corporate.filter(e => e.scheduledAt).map(e => ({ kind: 'corporate', at: Date.parse(e.scheduledAt), e }))
      .filter(row => row.at >= from - 864e5 && row.at <= to);
    return [...macro, ...corp].filter(row => {
      const category = row.kind === 'corporate' ? 'corporate' : row.e.category;
      if (filter.size && !filter.has(category)) return false;
      if (important && (row.kind === 'macro' ? row.e.importance < 3 : row.e.importanceScore < 8)) return false;
      return true;
    }).sort((a, b) => range === 'past' ? b.at - a.at : a.at - b.at);
  }
  function dots(level) { return `<span class="cal-imp" title="Важность ${level} из 3" aria-label="Важность ${level} из 3">${[1, 2, 3].map(i => `<i class="${i <= level ? 'on' : ''}"></i>`).join('')}</span>`; }
  function figures(e) {
    const unit = e.unit || '';
    const cell = (label, value, cls = '') => `<span class="cal-fig ${cls}"><small>${label}</small><b>${Number.isFinite(value) ? num(value) + unit : '—'}</b></span>`;
    if (![e.consensus, e.previous, e.actual].some(Number.isFinite)) return '';
    const s = e.surprise, cls = Number.isFinite(s) ? (s > 0 ? 'up' : s < 0 ? 'down' : '') : '';
    return `<div class="cal-figs">${cell('Факт', e.actual, 'actual ' + cls)}${cell('Консенсус', e.consensus)}${cell('Пред.', e.previous)}${Number.isFinite(s) ? `<span class="cal-fig ${cls}"><small>Отклонение</small><b>${s > 0 ? '+' : ''}${num(s)}${unit}</b></span>` : ''}</div>`;
  }
  function reaction(e) {
    if (e.locked) return '<p class="cal-locked">Реакция рынка и история — в <a href="/subscriptions.html?plan=pro">подписке PRO</a>.</p>';
    const parts = [];
    if (e.reaction?.horizons) {
      const h = e.reaction.horizons, cells = [['5m', '5 мин'], ['1h', '1 ч'], ['1d', '1 день']].filter(([k]) => h[k]).map(([k, label]) => `<span class="${h[k].changePct > 0 ? 'up' : h[k].changePct < 0 ? 'down' : ''}">${label}: ${pct(h[k].changePct)}</span>`);
      if (cells.length) parts.push(`<div class="cal-reaction"><small>${esc(e.reaction.instrument)} после события</small>${cells.join('')}</div>`);
    }
    if (e.history?.count) parts.push(`<p class="cal-history">Обычно за час после таких событий: ±${num(e.history.averageAbsPct)}% (${e.history.count} наблюд.)</p>`);
    return parts.join('');
  }
  function macroRow(e) {
    const past = Date.parse(e.scheduledAt) < Date.now();
    return `<li class="cal-row ${past ? 'past' : ''} imp-${e.importance}"><div class="cal-time">${e.allDay ? 'весь день' : clock(e.scheduledAt)}</div>
      <div class="cal-main"><div class="cal-title">${dots(e.importance)}<span class="cal-cat">${esc(e.categoryLabel)}</span><b>${esc(e.title)}</b>${e.recurring ? '<span class="cal-rule" title="Дата рассчитана по регулярному графику">по графику</span>' : ''}</div>
      ${e.note ? `<p class="cal-note">${esc(e.note)}</p>` : ''}${figures(e)}
      <div class="cal-links">${(e.instruments || []).map(code => `<span class="cal-inst">${esc(code)}</span>`).join('')}${(e.nodes || []).map(node => `<a class="cal-node" href="/graph.html?node=${encodeURIComponent(node)}">цепочки влияния →</a>`).slice(0, 1).join('')}${e.source ? `<a class="cal-src" href="${esc(e.source)}" target="_blank" rel="noopener noreferrer">источник ↗</a>` : ''}</div>
      ${reaction(e)}</div>${canEdit && !e.recurring ? `<button type="button" class="intel-button small" data-edit="${esc(e.id)}">Изменить</button>` : ''}</li>`;
  }
  function corporateRow(e) {
    return `<li class="cal-row corporate"><div class="cal-time">${e.scheduledAllDay ? 'весь день' : clock(e.scheduledAt)}</div>
      <div class="cal-main"><div class="cal-title"><span class="cal-cat corp">${esc(RADAR_TYPES[e.eventType] || 'Компания')}</span><b>${esc(e.ticker)} · ${esc(e.headline)}</b>${e.following ? '<span class="cal-rule">в моих</span>' : ''}</div>
      <div class="cal-links"><a class="cal-node" href="/radar.html?event=${encodeURIComponent(e.id)}">в Radar →</a><a class="cal-node" href="/graph.html?node=${encodeURIComponent('c:' + e.ticker)}">цепочки →</a></div></div></li>`;
  }
  function render() {
    const list = rows(), groups = new Map();
    for (const row of list) { const key = dayKey(row.at); if (!groups.has(key)) groups.set(key, []); groups.get(key).push(row); }
    $('calList').innerHTML = [...groups].map(([key, items]) => `<section class="cal-day"><h2>${esc(dayTitle(key))}</h2><ol>${items.map(row => row.kind === 'macro' ? macroRow(row.e) : corporateRow(row.e)).join('')}</ol></section>`).join('');
    $('calStatus').textContent = list.length ? '' : 'В этом периоде событий нет. Попробуйте другой период или фильтр.';
    $('calendarPage').setAttribute('aria-busy', 'false');
  }
  function openForm(event = null) {
    editing = event; const f = $('calForm'); f.hidden = false; f.reset(); $('calError').textContent = '';
    $('calFormTitle').textContent = event ? 'Изменить событие' : 'Новое событие'; $('calDelete').hidden = !event;
    if (event) {
      for (const key of ['title', 'category', 'unit', 'note', 'source']) f.elements[key].value = event[key] || '';
      for (const key of ['consensus', 'previous', 'actual']) f.elements[key].value = Number.isFinite(event[key]) ? event[key] : '';
      f.elements.importance.value = String(event.importance); f.elements.allDay.checked = !!event.allDay;
      f.elements.instruments.value = (event.instruments || []).join(', ');
      f.elements.scheduledAt.value = new Date(Date.parse(event.scheduledAt) + 3 * 3600000).toISOString().slice(0, 16);
    }
    f.scrollIntoView({ behavior: 'smooth', block: 'start' }); f.elements.title.focus({ preventScroll: true });
  }
  async function send(method, body) {
    const url = '/api/admin/intel/calendar' + (editing ? '?id=' + encodeURIComponent(editing.id) : '');
    const response = await fetch(url, { method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: method === 'DELETE' ? undefined : JSON.stringify(body) });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw Error(data.error || 'Не удалось сохранить.');
  }
  $('calForm').addEventListener('submit', async event => {
    event.preventDefault(); const f = event.target;
    const n = key => f.elements[key].value.trim() === '' ? null : Number(f.elements[key].value.replace(',', '.'));
    const body = { title: f.elements.title.value, category: f.elements.category.value, scheduledAt: f.elements.scheduledAt.value + ':00+03:00', allDay: f.elements.allDay.checked,
      importance: Number(f.elements.importance.value), unit: f.elements.unit.value, consensus: n('consensus'), previous: n('previous'), actual: n('actual'),
      instruments: f.elements.instruments.value.split(/[\s,;]+/).filter(Boolean), note: f.elements.note.value, source: f.elements.source.value };
    try { await send(editing ? 'PATCH' : 'POST', body); f.hidden = true; editing = null; await load(); } catch (error) { $('calError').textContent = error.message; }
  });
  $('calDelete').addEventListener('click', async () => { if (!editing || !confirm('Удалить событие из календаря?')) return; try { await send('DELETE'); $('calForm').hidden = true; editing = null; await load(); } catch (error) { $('calError').textContent = error.message; } });
  $('calCancel').addEventListener('click', () => { $('calForm').hidden = true; editing = null; });
  $('calAdd').addEventListener('click', () => openForm());
  $('calList').addEventListener('click', event => { const id = event.target.closest('[data-edit]')?.dataset.edit; if (id) openForm(events.find(e => e.id === id)); });
  document.querySelectorAll('[data-range]').forEach(button => button.addEventListener('click', () => {
    range = button.dataset.range; document.querySelectorAll('[data-range]').forEach(b => b.setAttribute('aria-pressed', String(b === button))); load().catch(fail);
  }));
  $('calCategories').addEventListener('click', event => { const b = event.target.closest('[data-category]'); if (!b) return; const key = b.dataset.category; if (filter.has(key)) filter.delete(key); else filter.add(key); b.setAttribute('aria-pressed', String(filter.has(key))); render(); });
  $('calImportant').addEventListener('change', render);
  const fail = error => { if (error.message !== 'auth') $('calStatus').textContent = error.message; };
  load().catch(fail);
})();
