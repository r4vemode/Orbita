import http from 'node:http';
import {readFile,realpath,stat} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createAccounts} from './lib/accounts.mjs';
import {createIdeas} from './lib/ideas.mjs';
import {createIdeaStream} from './lib/idea-stream.mjs';
import {readBundledDemoHistory,readDemoHistory} from './lib/demo-history.mjs';
import {historyStatistics,projectDemoTrade,publicHistoryScenarios} from './lib/trade-history.mjs';
import {createNews} from './lib/news.mjs';
import {createReferrals} from './lib/referrals.mjs';
import {RECURRING_TERMS_VERSION} from './lib/payment-recurring.mjs';
import {createPayments} from './lib/payments.mjs';
import {createTelegramClientMenu,isTelegramClientAction} from './lib/telegram-client/menu.mjs';
import {createTelegramContentWorkflow} from './lib/telegram-admin/content-workflow.mjs';
import {telegramAdminConfiguration} from './lib/telegram-admin/config.mjs';
import {createNotifications} from './lib/notifications.mjs';
import {createBackup} from './lib/backups.mjs';
import {createContent} from './lib/content.mjs';
import {createProductSettings} from './lib/product-settings.mjs';
import {buildMvpMetrics} from './lib/mvp-metrics.mjs';
import {PLANS,canReadTier,hasSubscription,isAdmin,requireAdmin,requireMember} from './lib/access.mjs';
import {json,readJson,error,safeFailure,originPolicy} from './lib/http.mjs';
import {checkStorage,createReadiness} from './lib/operations.mjs';
import {createRequestSecurity} from './lib/request-security.mjs';
import {createLegal} from './lib/legal.mjs';
import {createSalesGate} from './lib/sales-gate.mjs';
import {createRadar} from './lib/radar/service.mjs';
import {createParticipants} from './lib/participants.mjs';
import {createSupport} from './lib/support.mjs';
import {createDashboard} from './lib/dashboard.mjs';
import {createTelegramAdmin} from './lib/telegram-admin/service.mjs';
import {createTelegramLoginSender} from './lib/telegram-admin/login.mjs';
import {createMarkets} from './lib/markets/service.mjs';
import {buildShowcase} from './lib/showcase.mjs';
import {createPush} from './lib/push.mjs';
if(Number(process.versions.node.split('.')[0])<22)throw Error(`Для ORBITA нужен Node.js 22 или новее; рекомендуется Node.js 24 LTS. Сейчас установлен Node.js ${process.versions.node}. Обновите Node.js и повторите npm start.`);
const root=await realpath(fileURLToPath(new URL('./public/',import.meta.url)));
const configuredDirectory=process.env.ORBITA_DATA_DIR||fileURLToPath(new URL('./data/',import.meta.url));
const startupStorage=await checkStorage({directory:configuredDirectory,publicDir:root,write:true,validate:true});
if(startupStorage.code==='DATA_DIR_PUBLIC')throw Error('ORBITA_DATA_DIR должен находиться вне публичной папки public.');
if(!startupStorage.ok)throw Error(`Хранилище ORBITA не готово. Код: ${startupStorage.code}${startupStorage.store?' ('+startupStorage.store+')':''}. Запустите npm run preflight для диагностики.`);
const directory=await realpath(configuredDirectory);
if(directory===root||directory.startsWith(root+path.sep))throw Error('ORBITA_DATA_DIR должен находиться вне публичной папки public.');
const mfaSetting=process.env.ORBITA_REQUIRE_ADMIN_MFA;
if(mfaSetting!==undefined&&!['true','false','1','0'].includes(mfaSetting))throw Error('ORBITA_REQUIRE_ADMIN_MFA: используйте true или false.');
const port=Number(process.env.PORT||3000),host=process.env.HOST||'127.0.0.1';
if(!Number.isInteger(port)||port<0||port>65535)throw Error('PORT должен быть числом от 0 до 65535.');
const historySetting=process.env.ORBITA_LOCAL_MARKET_HISTORY;
const shareOriginPolicy=originPolicy(process.env.ORBITA_PUBLIC_ORIGIN);
const sharePublicOrigin=shareOriginPolicy.secure?shareOriginPolicy.publicOrigin:'https://orbitaview.ru';
const localMarketHistory=(historySetting==='true'||(historySetting!=='false'&&process.argv.includes('--local-market-history')))
  &&process.env.NODE_ENV!=='production'&&!process.env.ORBITA_PUBLIC_ORIGIN&&['127.0.0.1','::1','localhost'].includes(host);
const useBundledHistory=!process.argv.includes('--without-bundled-history');
let accounts;
const legal=await createLegal(directory,{templateDir:root,accounts:{identify:req=>accounts.identify(req)},authorizePublish:(req,credentials)=>accounts.authorizeSensitive(req,credentials)});
accounts=await createAccounts(directory,{...(mfaSetting===undefined?{}:{requireAdminMfa:['true','1'].includes(mfaSetting)}),legalVersionProvider:async()=>(await legal.readPublic()).version,telegramLogin:createTelegramLoginSender()});
const ideas=await createIdeas(directory,{localMarketHistory});
const ideaStream=createIdeaStream({accounts,ideas});
const content=await createContent(directory,{accounts}),news=createNews(directory,{content});
const payments=await createPayments(directory,{accounts,checkoutGate:createSalesGate({legal}),recurringGate:()=>legal.recurringReadiness(RECURRING_TERMS_VERSION)});
const referrals=createReferrals({accounts,publicOrigin:process.env.ORBITA_PUBLIC_ORIGIN||'',simulation:(await payments.publicConfig()).simulation});
const radar=await createRadar(directory,{accounts,ideas});
const participants=await createParticipants(directory,{accounts});
const markets=await createMarkets(directory,{accounts,ideas});
const support=await createSupport(directory,{accounts});
const dashboard=createDashboard({accounts,ideas,radar,support});
const push=await createPush(directory,{accounts});
const clientMenu={...createTelegramClientMenu({ideas,radar,content,publicOrigin:process.env.ORBITA_PUBLIC_ORIGIN}),isAction:isTelegramClientAction};
const notifications=await createNotifications(directory,{accounts,ideas,radar,content,clientMenu,markets,push});
const adminBot=telegramAdminConfiguration();
const editorWorkflow=adminBot.configured?createTelegramContentWorkflow({content,publicOrigin:adminBot.publicOrigin}):null;
const telegramAdmin=createTelegramAdmin({accounts,ideas,radar,notifications,editorWorkflow});
const productSettings=await createProductSettings(directory,{accounts});
const readiness=createReadiness({directory,publicDir:root});
const webhooks=new Set([...payments.webhookPaths,...notifications.webhookPaths,...telegramAdmin.webhookPaths]);
const requestSecurity=createRequestSecurity({trustedProxyIps:process.env.ORBITA_TRUSTED_PROXY_IPS||''});
const types={'.html':'text/html','.webmanifest':'application/manifest+json','.json':'application/json','.css':'text/css','.js':'text/javascript','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon','.woff2':'font/woff2'};
const memberPages=new Set(['/app.html','/calculator.html','/learn.html','/markets.html']);
// Legacy addresses keep working after the sections were merged.
const movedPages=new Map([['/participants.html','/markets.html'],['/market-demo.html','/markets.html']]);
const accountPages=new Set(['/subscriptions.html','/security.html','/notifications.html','/support.html','/dashboard.html','/partner.html']);
const accountAssets=new Set(['/assets/support.js','/assets/dashboard.js','/assets/referrals.js']);
const adminPages=new Set(['/admin.html','/content-admin.html','/settings-admin.html','/launch-admin.html','/legal-admin.html','/radar-admin.html','/support-admin.html','/telegram-admin.html','/payments-admin.html','/partners-admin.html','/backtest-admin.html','/markets-admin.html']);
const radarPages=new Set(['/radar.html']),radarAssets=new Set(['/assets/radar.js']);
const paidAssets=new Set(['/assets/markets.js','/assets/app.js','/assets/signal-visual.js','/assets/calculator.js','/assets/learning-data.js','/assets/learning.js','/assets/news.js','/assets/personal.js','/assets/participants.js','/assets/member-session.js']);
const adminAssets=new Set(['/assets/markets-admin.js','/assets/admin.js','/assets/content-admin.js','/assets/settings-admin.js','/assets/launch-admin.js','/assets/legal-admin.js','/assets/radar-admin.js','/assets/admin-session.js','/assets/support-admin.js','/assets/telegram-admin.js','/assets/payments-admin.js','/assets/backtest-admin.js','/assets/backtest-engine.js','/assets/result-share.js','/assets/result-share-card.js']);
const removedAssets=new Set(['/assets/editor-seed.js']);
function redirect(res,destination){res.writeHead(303,{Location:destination,'Cache-Control':'no-store','Vary':'Cookie'});res.end();}
function probe(res,status,data,head=false){const body=JSON.stringify(data);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Content-Length':Buffer.byteLength(body)});res.end(head?undefined:body);}
async function demoTrades({publicArchive=false}={}){
 try{
  if(publicArchive)return useBundledHistory?await readBundledDemoHistory():[];
  return await readDemoHistory(directory,{useBundled:useBundledHistory});
 }
 catch{throw error(503,'Исторические сценарии временно недоступны. Проверьте состояние хранилища.','DEMO_HISTORY_UNAVAILABLE');}
}
const server=http.createServer({maxHeaderSize:16384,headersTimeout:15000,requestTimeout:20000,keepAliveTimeout:5000,connectionsCheckingInterval:1000},async(req,res)=>{
 let requestRoute='unknown';
 try{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=(), payment=(), usb=()');
  res.setHeader('Cross-Origin-Opener-Policy','same-origin');res.setHeader('Cross-Origin-Resource-Policy','same-origin');
  if(process.env.ORBITA_PUBLIC_ORIGIN?.startsWith('https://'))res.setHeader('Strict-Transport-Security','max-age=31536000');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; worker-src 'self'; manifest-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'");
  if(!req.url?.startsWith('/')||req.url.startsWith('//'))throw error(400,'Некорректный путь.');
  const url=new URL(req.url,'http://localhost');
  let pathname;try{pathname=decodeURIComponent(url.pathname);}catch{throw error(400,'Некорректный адрес.');}
  requestRoute=pathname;
  if(pathname.includes('\\')||pathname.includes('\0'))throw error(400,'Некорректный путь.');
  if(pathname==='/healthz'||pathname==='/readyz'){
   if(!['GET','HEAD'].includes(req.method)){res.writeHead(405,{Allow:'GET, HEAD','Cache-Control':'no-store'}).end();return;}
   if(pathname==='/healthz'){probe(res,200,{status:'ok'},req.method==='HEAD');return;}
   const state=await readiness.status();probe(res,state.ready?200:503,{status:state.ready?'ready':'not_ready'},req.method==='HEAD');return;
  }
  if(pathname.startsWith('/r/')){accounts.checkRequest(req);if(!requestSecurity.enter(req,res))return;if(await referrals.visit(req,res,url))return;throw error(404,'Ссылка не найдена.');}
  // Authorize the normalized filesystem target, not an encoded URL alias.
  const target=path.resolve(root,'.'+(pathname==='/'?'/index.html':pathname));
  if(!target.startsWith(root+path.sep))throw error(403,'Доступ запрещён.');
  const canonical='/'+path.relative(root,target).split(path.sep).join('/');
  if(canonical.split('/').some((segment,index)=>segment.startsWith('.')&&!(index===1&&segment==='.well-known')))throw error(403,'Доступ запрещён.');
  if(pathname.startsWith('/api/')){
   // Only these provider callbacks bypass the browser Origin requirement. Each
   // service authenticates the untouched body or the provider's secret header.
   const webhook=webhooks.has(url.pathname);
   accounts.checkRequest(webhook?{method:'GET',headers:req.headers}:req);
   const streamRequest=url.pathname==='/api/ideas/stream'&&req.method==='GET';
   const requestAdmission=requestSecurity.enter(req,res,{webhook,longLived:streamRequest});
   if(!requestAdmission)return;
   if(webhook){
    if(await payments.handle(req,res,url,null)||await notifications.handle(req,res,url,null)||await telegramAdmin.handle(req,res,url,null))return;
   }
   accounts.checkRequest(req);
   if(await accounts.handle(req,res,url))return;
   const user=await accounts.identify(req);
   if(url.pathname==='/api/ideas/stream'){
    if(!streamRequest){json(res,405,{error:'Метод не поддерживается.'},{Allow:'GET'});return;}
    await ideaStream.open(req,res,user,requestAdmission);
    return;
   }
   const includeLocalMarketHistory=localMarketHistory&&/^(localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/i.test(req.headers.host||'')
     &&!req.headers.forwarded&&!req.headers['x-forwarded-host'];
   if(await payments.handle(req,res,url,user)||await notifications.handle(req,res,url,user))return;
   if(await referrals.handle(req,res,url,user)||await telegramAdmin.handle(req,res,url,user)||await dashboard.handle(req,res,url,user)||await support.handle(req,res,url,user)||await participants.handle(req,res,url,user)||await markets.handle(req,res,url,user)||await push.handle(req,res,url,user)||await radar.handle(req,res,url,user)||await legal.handle(req,res,url,user)||await content.handle(req,res,url,user)||await productSettings.handle(req,res,url,user))return;
   if(url.pathname==='/api/public-config'&&req.method==='GET'){const settings=await productSettings.readPublic(),paymentConfig=await payments.publicConfig(),publication=await legal.readPublic();json(res,200,{legalVersion:await accounts.currentLegalVersion(),plans:PLANS,paymentsAvailable:paymentConfig.checkoutEnabled,mailEnabled:accounts.emailConfigured,telegramEnabled:notifications.configured,supportEmail:settings.supportEmail||process.env.ORBITA_SUPPORT_EMAIL||publication.profile.supportEmail||null,authorName:settings.authorName,editorialNote:settings.editorialNote});return;}
   if(url.pathname==='/api/admin/readiness'){requireAdmin(user);if(req.method!=='GET')throw error(405,'Метод не поддерживается.');const settings=await productSettings.readPublic();json(res,200,await readiness.adminReport({supportEmail:settings.supportEmail}));return;}
   if(url.pathname==='/api/admin/metrics'){requireAdmin(user);if(req.method!=='GET')throw error(405,'Метод не поддерживается.');let billing;try{billing=JSON.parse(await readFile(path.join(directory,'billing.json'),'utf8'));}catch(cause){if(cause.code!=='ENOENT')throw cause;}json(res,200,{metrics:buildMvpMetrics({accounts:await accounts.readDatabase(),billing}),checkedAt:new Date().toISOString()});return;}
   if(url.pathname==='/api/public/results'&&req.method==='GET'){json(res,200,await ideas.results());return;}
   if(url.pathname==='/api/public/history-scenarios'&&req.method==='GET'){json(res,200,publicHistoryScenarios(await demoTrades({publicArchive:true})));return;}
   if(includeLocalMarketHistory&&url.pathname==='/api/local/market-history'&&req.method==='GET'){json(res,200,await ideas.results({localMarketHistory:true}));return;}
   if(url.pathname==='/api/public/stats'&&req.method==='GET'){json(res,200,{stats:await ideas.stats(),checkedAt:new Date().toISOString()});return;}
   if(url.pathname==='/api/public/showcase'&&req.method==='GET'){json(res,200,{showcase:await buildShowcase({ideas,markets})});return;}
   if(url.pathname==='/api/history/statistics'&&req.method==='GET'){
    requireMember(user);
    const tier=url.searchParams.get('tier'),type=url.searchParams.get('type');
    const market=url.searchParams.get('market'),strategy=url.searchParams.get('strategy');
    if(!['pro','exclusive'].includes(tier)||!['demo','actual'].includes(type)||market&&!['stocks','futures','crypto'].includes(market)||strategy?.length>120)throw error(400,'Некорректные фильтры истории.');
    if(!canReadTier(user,tier))throw error(403,'История доступна по соответствующей подписке.');
    const records=type==='demo'?{trades:await demoTrades()}:{published:(await ideas.results()).results};
    json(res,200,historyStatistics({tier,type,market,strategy,...records}));return;
   }
   if(url.pathname==='/api/ideas'&&req.method==='GET'){
    const observedAt=Date.now();
    const feed=await ideas.list(user);
    let quotes={},specs={},trades=[],demoHistoryError;
    try{quotes=await markets.quotesFor(feed.records);specs=await markets.specsFor(feed.records);}catch{}
    try{trades=await demoTrades();}catch(cause){demoHistoryError=cause.code;}
    const accessible=trades.filter(trade=>canReadTier(user,trade.tier)).map(projectDemoTrade);
    json(res,200,{...feed,viewerId:user.id,observedAt,records:[...feed.records,...accessible],quotes,specs,demoHistory:trades.length>0,demoHistoryError,localMarketHistory:includeLocalMarketHistory});return;
   }
   const single=url.pathname.match(/^\/api\/ideas\/([a-zA-Z0-9_-]+)$/);
   if(single&&req.method==='GET'){
    if(single[1].startsWith('demo-history-')){
     requireMember(user);
     const trade=(await demoTrades()).find(row=>row.id===single[1]);
     if(!trade||!canReadTier(user,trade.tier))throw error(404,'Идея недоступна.');
     json(res,200,{record:projectDemoTrade(trade)});return;
    }
    json(res,200,{record:await ideas.get(single[1],user,{includeLocalMarketHistory})});return;
   }
   if(url.pathname==='/api/news'){requireMember(user);if(await news(req,res,url,user))return;}
   if(url.pathname==='/api/admin/ideas'){
    requireAdmin(user);if(req.method==='GET'){json(res,200,await ideas.list(user));return;}if(req.method==='POST'){const payload=await readJson(req),current=await accounts.identify(req);requireAdmin(current);if(Object.hasOwn(payload,'radarDraftToken')){const {radarDraftToken,...input}=payload;json(res,201,await telegramAdmin.workflow.publish(current,input,{draftToken:radarDraftToken,req}));}else json(res,201,await ideas.create(current,payload));return;}
   }
   const shareIdea=url.pathname.match(/^\/api\/admin\/ideas\/([a-zA-Z0-9_-]+)\/share-card$/);
   if(shareIdea){
    requireAdmin(user);
    if(req.method!=='GET'){json(res,405,{error:'Метод не поддерживается.'},{Allow:'GET'});return;}
    const card=await ideas.shareResult(user,shareIdea[1]);
    json(res,200,{card:{...card,publicOrigin:sharePublicOrigin}});return;
   }
   const adminIdea=url.pathname.match(/^\/api\/admin\/ideas\/([a-zA-Z0-9_-]+)(\/events)?$/);
   if(adminIdea){requireAdmin(user);if(adminIdea[2]&&req.method==='POST'||!adminIdea[2]&&req.method==='PUT'){const payload=await readJson(req),current=await accounts.identify(req);requireAdmin(current);json(res,200,await ideas.update(current,adminIdea[1],payload));return;}if(!adminIdea[2]&&req.method==='DELETE'){const current=await accounts.identify(req);requireAdmin(current);json(res,200,await ideas.remove(current,adminIdea[1]));return;}}
   throw error(404,'Неизвестный запрос.');
  }
  accounts.checkRequest(req);
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405,{Allow:'GET, HEAD'}).end();return;}
  if(removedAssets.has(canonical))throw error(404,'Файл не найден.');
  if(movedPages.has(canonical)){res.writeHead(301,{Location:movedPages.get(canonical),'Cache-Control':'no-store'});res.end();return;}
  const protectedPage=memberPages.has(canonical)||adminPages.has(canonical)||accountPages.has(canonical)||radarPages.has(canonical);
  const protectedAsset=paidAssets.has(canonical)||accountAssets.has(canonical)||adminAssets.has(canonical)||radarAssets.has(canonical);
  if(protectedPage||protectedAsset){
   if(!requestSecurity.enter(req,res))return;
   const user=await accounts.identify(req);
   if(!user){if(protectedAsset)throw error(401,'Войдите в аккаунт.');redirect(res,'/account.html?next='+encodeURIComponent(canonical+url.search));return;}
   if(adminPages.has(canonical)||adminAssets.has(canonical)){if(!isAdmin(user)){if(protectedAsset)throw error(403,'Доступ только для администратора.');redirect(res,user.security?.adminEnrollmentRequired?'/security.html?setup=1':'/subscriptions.html?error=admin');return;}}
   else if(radarPages.has(canonical)||radarAssets.has(canonical)){if(!radar.canAccess(user)){if(protectedAsset)throw error(403,'Radar доступен по подключённому тарифу.','SUBSCRIPTION_REQUIRED');redirect(res,'/subscriptions.html?plan='+encodeURIComponent(radar.config.allowedPlans[0])+'&next='+encodeURIComponent(canonical+url.search));return;}}
   else if(!accountPages.has(canonical)&&!accountAssets.has(canonical)&&!hasSubscription(user)){if(protectedAsset)throw error(403,'Для доступа нужна действующая подписка.');redirect(res,'/subscriptions.html?next='+encodeURIComponent(canonical+url.search));return;}
  }
  const real=await realpath(target).catch(e=>{if(e.code==='ENOENT'||e.code==='ENOTDIR')throw error(404,'Файл не найден.');throw e;});
  if(!real.startsWith(root+path.sep)||real!==target)throw error(403,'Доступ запрещён.');
  if(!(await stat(real)).isFile())throw error(404,'Файл не найден.');
  const documentName={'/offer.html':'offer','/privacy.html':'privacy','/refunds.html':'refunds'}[canonical];
  const bytes=documentName?Buffer.from(await legal.renderPage(documentName,{version:url.searchParams.get('version')||undefined})):await readFile(real);
  const extension=path.extname(real),mime=types[extension]||'application/octet-stream';
  res.writeHead(200,{'Content-Type':extension==='.woff2'?mime:mime+'; charset=utf-8','Cache-Control':'no-store','Vary':'Cookie'});
  res.end(req.method==='HEAD'?undefined:bytes);
 }catch(e){if(!res.headersSent){if(e.status)json(res,e.status,{error:e.message,...(e.code?{code:e.code}:{})});else safeFailure(res,e,{scope:'server',route:requestRoute});}else res.end();}
});
server.maxHeadersCount=100;server.maxRequestsPerSocket=1000;
server.on('error',e=>{const code=typeof e.code==='string'&&/^[A-Z][A-Z0-9_]{1,63}$/.test(e.code)?e.code:'UNEXPECTED';console.error(code==='EADDRINUSE'?`Port ${port} is busy. Stop the other server or set PORT.`:`ORBITA server error code=${code}`);process.exitCode=1;});
function interval(name,fallback,min,max){const value=Number(process.env[name]||fallback);if(!Number.isFinite(value)||value<min||value>max)throw Error(`${name}: допустимо от ${min} до ${max}.`);return value;}
const timers=[],backgroundJobs=new Set();
function schedule(task,milliseconds,label){let running=null;const run=()=>{if(running)return;const job=Promise.resolve().then(task).catch(()=>console.error(`${label}: операция не завершена; проверьте конфигурацию и доступность службы.`)).finally(()=>{running=null;backgroundJobs.delete(job);});running=job;backgroundJobs.add(job);};run();const timer=setInterval(run,milliseconds);timer.unref();timers.push(timer);}
const notificationInterval=interval('ORBITA_NOTIFICATION_INTERVAL_SECONDS',60,5,3600);
const backupHours=interval('ORBITA_BACKUP_INTERVAL_HOURS',24,1,8760),backupKeep=interval('ORBITA_BACKUP_KEEP',7,1,1000);
if(!Number.isInteger(backupKeep))throw Error('ORBITA_BACKUP_KEEP должен быть целым числом.');
const backupDir=process.env.ORBITA_BACKUP_DIR,backupPassphrase=process.env.ORBITA_BACKUP_PASSPHRASE;
if(Boolean(backupDir)!==Boolean(backupPassphrase))throw Error('Для автоматических копий укажите и ORBITA_BACKUP_DIR, и ORBITA_BACKUP_PASSPHRASE.');
server.listen(port,host,()=>{
 const address=process.env.ORBITA_PUBLIC_ORIGIN||`http://${host.includes(':')?'['+host+']':host}:${server.address().port}`;
 console.log(`ORBITA: ${address}`);
 if(localMarketHistory)console.log(`Дейтрейдинг → История (локальные сценарии): ${address}/strategies.html`);
 telegramAdmin.start();
 schedule(()=>content.publishDue(),30000,'Публикации редакции');
 void radar.start().catch(()=>console.error('Radar: не удалось запустить получение источников; проверьте приватное хранилище и состояние адаптеров.'));
 void markets.start().catch(()=>console.error('Рынки: не удалось запустить обновление данных MOEX; см. диагностику в редакции.'));
 void participants.start().catch(()=>console.error('Позиции участников: получение данных временно недоступно; проверьте настройки и подключение источника.'));
 if(payments.configured)schedule(()=>payments.sync(),60000,'CloudPayments');
 if(notifications.configured||push.configured)schedule(()=>notifications.tick(),notificationInterval*1000,'Уведомления');
 // Instant delivery: idea events (entry, stop, target…) trigger a pass immediately; the interval stays as a safety net.
 if(notifications.configured||push.configured)ideas.subscribe(()=>{void notifications.tick().catch(()=>{});});
 if(backupDir)schedule(()=>createBackup({dataDir:directory,backupDir,passphrase:backupPassphrase,publicDir:root,keep:backupKeep}),backupHours*3600000,'Резервная копия');
});
let stopping=false;
async function stop(){
 if(stopping)return;stopping=true;readiness.setDraining();timers.forEach(clearInterval);
 ideaStream.close();
 const closeHttp=server.listening?new Promise(resolve=>server.close(()=>resolve())):Promise.resolve();
 server.closeIdleConnections?.();const work=Promise.allSettled([closeHttp,telegramAdmin.close(),support.close(),participants.close(),markets.close(),radar.close(),notifications.close(),accounts.flushMail(),content.close(),legal.close(),Promise.allSettled([...backgroundJobs])]);let timer;
 const outcome=await Promise.race([work.then(()=>true),new Promise(resolve=>{timer=setTimeout(()=>resolve(false),10000);})]);clearTimeout(timer);
 if(!outcome){console.error('ORBITA shutdown timeout: процесс завершён принудительно.');server.closeAllConnections?.();process.exit(1);}
}
process.on('SIGTERM',()=>{void stop();});process.on('SIGINT',()=>{void stop();});
