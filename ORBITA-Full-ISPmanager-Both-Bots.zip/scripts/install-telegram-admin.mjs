import {createDecipheriv, randomUUID} from 'node:crypto';
import {constants} from 'node:fs';
import {open, readFile, realpath, rename, rm, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {createInterface} from 'node:readline/promises';
import {Writable} from 'node:stream';
import {fileURLToPath} from 'node:url';
import {parseEnv} from 'node:util';
import {telegramAdminConfiguration} from '../lib/telegram-admin/config.mjs';
import {telegramNotificationConfiguration} from '../lib/notifications.mjs';

const dataDir = process.env.ORBITA_DATA_DIR || '/var/www/www-root/data/orbita-private';
const keys = new Set([
  'TELEGRAM_ADMIN_BOT_TOKEN',
  'TELEGRAM_ADMIN_BOT_USERNAME',
  'TELEGRAM_ADMIN_WEBHOOK_SECRET',
  'TELEGRAM_ADMIN_BOT_ENABLED',
  'TELEGRAM_BOT_TOKEN',
  'TELEGRAM_BOT_USERNAME',
  'TELEGRAM_WEBHOOK_SECRET'
]);

async function readKey() {
  const muted = new Writable({write(_chunk, _encoding, done) { done(); }});
  const reader = createInterface({input: process.stdin, output: muted, terminal: process.stdin.isTTY});
  try {
    process.stdout.write('Ключ установки: ');
    return (await reader.question('')).trim();
  } finally {
    reader.close();
    process.stdout.write('\n');
  }
}

async function readSettings(filename) {
  let file;
  try {
    file = await open(filename, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
  } catch (cause) {
    if (cause.code === 'ENOENT') return '';
    throw cause;
  }
  try {
    const info = await file.stat();
    if (!info.isFile() || info.size > 16384) throw Error('Нужен обычный файл .env.telegram.');
    return await file.readFile('utf8');
  } finally {
    await file.close();
  }
}

async function install() {
  const key = await readKey();
  if (!/^[a-f0-9]{64}$/.test(key)) throw Error('Вставьте ключ установки целиком.');
  const bundle = await readFile(new URL('telegram-admin-settings.enc', import.meta.url));
  let settings;
  try {
    const decipher = createDecipheriv('aes-256-gcm', Buffer.from(key, 'hex'), bundle.subarray(0, 12));
    decipher.setAuthTag(bundle.subarray(12, 28));
    settings = Buffer.concat([decipher.update(bundle.subarray(28)), decipher.final()]).toString('utf8');
  } catch {
    throw Error('Ключ не подошёл к этому архиву.');
  }

  const incoming = parseEnv(settings);
  if (Object.keys(incoming).length !== keys.size || [...keys].some(name => !incoming[name])) {
    throw Error('Настройки в архиве повреждены.');
  }
  const directory = await realpath(dataDir);
  const project = await realpath(fileURLToPath(new URL('../', import.meta.url)));
  if (directory === project || directory.startsWith(project + path.sep)) {
    throw Error('ORBITA_DATA_DIR должен находиться вне папки сайта.');
  }
  const filename = path.join(directory, '.env.telegram');
  const previous = await readSettings(filename);
  const kept = previous.split(/\r?\n/).filter(line => {
    const name = line.match(/^\s*(?:export\s+)?([A-Za-z_]\w*)\s*=/)?.[1];
    return !keys.has(name);
  }).join('\n').trimEnd();
  const updated = kept ? kept + '\n' + settings : settings;
  const merged = parseEnv(updated);
  if ([...keys].some(name => merged[name] !== incoming[name])) throw Error('В .env.telegram есть незакрытая кавычка.');
  const env = {...merged, ORBITA_PUBLIC_ORIGIN: 'https://orbitaview.ru'};
  if (!telegramAdminConfiguration(env).configured || !telegramNotificationConfiguration({}, env).configured) {
    throw Error('Настройки Telegram неполные.');
  }

  const temporary = filename + '.' + randomUUID() + '.tmp';
  try {
    await writeFile(temporary, updated, {flag: 'wx', mode: 0o600});
    await rename(temporary, filename);
  } finally {
    await rm(temporary, {force: true});
  }
  console.log('Настройки обоих ботов сохранены. Перезапустите Node.js в ISPmanager.');
}

try {
  await install();
} catch (cause) {
  const details = cause.code ? 'Ошибка установки (' + cause.code + ').' : cause.message;
  console.error(details);
  process.exitCode = 1;
}
