/* ORBITA · hero globe: a rotating dot sphere with orbits, comets and market "pings".
   Canvas 2D, DPR-aware, paused off-screen and in hidden tabs, static for reduced motion. */
(() => {
  'use strict';
  const canvas = document.querySelector('.hx-globe');
  if (!canvas || !canvas.getContext) return;
  const ctx = canvas.getContext('2d');
  const calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const light = () => document.documentElement.dataset.theme === 'light';
  const N = 1100, TILT = -0.38, points = [];
  // Fibonacci sphere: an even, "engineered" dot grid.
  const golden = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < N; i++) {
    const y = 1 - (i / (N - 1)) * 2, r = Math.sqrt(1 - y * y), a = golden * i;
    points.push({ x: Math.cos(a) * r, y, z: Math.sin(a) * r, seed: Math.random() });
  }
  const pings = [];
  const arcs = [];
  const orbits = [
    { rx: 1.55, ry: 0.42, rot: -0.32, speed: 0.00016, phase: 0, color: [168, 201, 255], size: 2.6 },
    { rx: 1.95, ry: 0.62, rot: 0.18, speed: -0.0001, phase: 2.1, color: [241, 207, 143], size: 2.2 },
    { rx: 2.35, ry: 0.5, rot: -0.12, speed: 0.00007, phase: 4.2, color: [111, 211, 162], size: 1.9 }
  ];
  let w = 0, h = 0, dpr = 1, R = 0, cx = 0, cy = 0, running = false, visible = true, last = 0, raf = 0;

  function resize() {
    const box = canvas.getBoundingClientRect();
    dpr = Math.min(2, devicePixelRatio || 1); w = box.width; h = box.height;
    canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    R = Math.min(w, h) * 0.34; cx = w * 0.5; cy = h * 0.5;
  }
  const rotate = (p, angle) => {
    const ca = Math.cos(angle), sa = Math.sin(angle);
    let x = p.x * ca + p.z * sa, z = -p.x * sa + p.z * ca, y = p.y;
    const ct = Math.cos(TILT), st = Math.sin(TILT);
    const y2 = y * ct - z * st, z2 = y * st + z * ct;
    return { x, y: y2, z: z2 };
  };
  const project = p => ({ x: cx + p.x * R, y: cy + p.y * R, z: p.z });
  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;

  function orbitPoint(o, t) {
    const a = o.phase + t * o.speed * 1000 / 16, ex = Math.cos(a) * o.rx, ey = Math.sin(a) * o.ry;
    const cr = Math.cos(o.rot), sr = Math.sin(o.rot);
    return { x: cx + (ex * cr - ey * sr) * R, y: cy + (ex * sr + ey * cr) * R, front: Math.sin(a) > 0 };
  }
  function drawOrbit(o, t, front) {
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(o.rot);
    ctx.beginPath();
    // Back half dimmer, front half brighter, so the rings wrap around the globe.
    ctx.ellipse(0, 0, o.rx * R, o.ry * R, 0, front ? 0 : Math.PI, front ? Math.PI : Math.PI * 2);
    ctx.strokeStyle = rgba(light() ? [61, 93, 143] : o.color, front ? 0.28 : 0.1);
    ctx.lineWidth = 1; ctx.stroke(); ctx.restore();
    // Comet with a fading tail.
    for (let k = 26; k >= 0; k--) {
      const p = orbitPoint(o, t - k * 18);
      if (p.front !== front) continue;
      const alpha = (1 - k / 26) * (front ? 0.9 : 0.35);
      ctx.beginPath(); ctx.arc(p.x, p.y, o.size * (k ? 0.75 * (1 - k / 30) : 1), 0, Math.PI * 2);
      ctx.fillStyle = rgba(o.color, alpha); ctx.fill();
    }
    const head = orbitPoint(o, t);
    if (head.front === front) {
      const g = ctx.createRadialGradient(head.x, head.y, 0, head.x, head.y, 16);
      g.addColorStop(0, rgba(o.color, front ? 0.55 : 0.2)); g.addColorStop(1, rgba(o.color, 0));
      ctx.fillStyle = g; ctx.fillRect(head.x - 16, head.y - 16, 32, 32);
    }
  }

  function frame(t) {
    ctx.clearRect(0, 0, w, h);
    const orbitTime = t / 2;
    const angle = t * 0.00006, dark = !light();
    // Outer atmosphere: a halo that starts at the limb, nothing inside it.
    const halo = ctx.createRadialGradient(cx, cy, R * 0.98, cx, cy, R * 1.45);
    halo.addColorStop(0, dark ? 'rgba(127,178,255,0.28)' : 'rgba(61,111,182,0.16)');
    halo.addColorStop(0.35, dark ? 'rgba(80,130,210,0.10)' : 'rgba(61,111,182,0.06)');
    halo.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = halo; ctx.beginPath(); ctx.arc(cx, cy, R * 1.45, 0, Math.PI * 2); ctx.fill();
    for (const o of orbits) drawOrbit(o, orbitTime, false);
    // Body: deep navy, lit from the upper right, hides the back orbits.
    const body = ctx.createRadialGradient(cx + R * 0.35, cy - R * 0.4, R * 0.05, cx, cy, R);
    body.addColorStop(0, dark ? '#24395c' : '#e9f1fd'); body.addColorStop(0.55, dark ? '#0f1a2e' : '#dbe6f7'); body.addColorStop(1, dark ? '#070c17' : '#c9d8ef');
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fillStyle = body; ctx.fill();
    // Thin limb light, brightest on the lit side.
    const limb = ctx.createLinearGradient(cx - R, cy + R, cx + R, cy - R);
    limb.addColorStop(0, dark ? 'rgba(168,201,255,0.05)' : 'rgba(61,111,182,0.1)'); limb.addColorStop(1, dark ? 'rgba(220,236,255,0.75)' : 'rgba(61,111,182,0.6)');
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.strokeStyle = limb; ctx.lineWidth = 1.2; ctx.stroke();
    // Dots: back hemisphere faint, front bright; size by depth.
    const base = dark ? [178, 208, 255] : [44, 84, 150];
    const projected = [];
    for (const p of points) {
      const q = project(rotate(p, angle));
      projected.push(q);
      const depth = (q.z + 1) / 2;
      const twinkle = 0.75 + 0.25 * Math.sin(t * 0.0015 + p.seed * 40);
      if (q.z < 0) continue; const alpha = (0.12 + depth * 0.78) * twinkle;
      ctx.fillStyle = rgba(base, alpha);
      const s = 0.9 + depth * 1.3;
      ctx.beginPath(); ctx.arc(q.x, q.y, s / 2, 0, Math.PI * 2); ctx.fill();
    }
    // Market pings: a front point flashes green/red/gold and ripples.
    if (!calm && Math.random() < 0.06 && pings.length < 9) {
      const i = Math.floor(Math.random() * N);
      if (projected[i].z > 0.15) pings.push({ i, born: t, color: [[111, 211, 162], [239, 133, 128], [241, 207, 143]][Math.floor(Math.random() * 3)] });
    }
    for (let k = pings.length - 1; k >= 0; k--) {
      const ping = pings[k], age = (t - ping.born) / 1600;
      if (age > 1) { pings.splice(k, 1); continue; }
      const q = projected[ping.i]; if (q.z < 0) continue;
      ctx.beginPath(); ctx.arc(q.x, q.y, 2 + age * 14, 0, Math.PI * 2);
      ctx.strokeStyle = rgba(ping.color, 0.7 * (1 - age)); ctx.lineWidth = 1; ctx.stroke();
      ctx.beginPath(); ctx.arc(q.x, q.y, 2.2, 0, Math.PI * 2); ctx.fillStyle = rgba(ping.color, 1 - age * 0.6); ctx.fill();
    }
    // Arcs between two front points: "flows" of capital.
    if (!calm && Math.random() < 0.012 && arcs.length < 3) {
      const a = Math.floor(Math.random() * N), b = Math.floor(Math.random() * N);
      if (projected[a].z > 0.3 && projected[b].z > 0.3) arcs.push({ a, b, born: t });
    }
    for (let k = arcs.length - 1; k >= 0; k--) {
      const arc = arcs[k], age = (t - arc.born) / 2600;
      if (age > 1) { arcs.splice(k, 1); continue; }
      const p = projected[arc.a], q = projected[arc.b];
      if (p.z < 0 || q.z < 0) continue;
      const mx = (p.x + q.x) / 2, my = (p.y + q.y) / 2, lift = Math.hypot(q.x - p.x, q.y - p.y) * 0.45;
      const nx = (mx - cx), ny = (my - cy), len = Math.hypot(nx, ny) || 1;
      const ctrl = { x: mx + nx / len * lift, y: my + ny / len * lift };
      const grad = ctx.createLinearGradient(p.x, p.y, q.x, q.y);
      const head = Math.min(1, age * 1.6);
      grad.addColorStop(0, 'rgba(168,201,255,0)'); grad.addColorStop(Math.max(0, head - 0.25), 'rgba(168,201,255,0)');
      grad.addColorStop(head, `rgba(220,235,255,${0.8 * (1 - age)})`); grad.addColorStop(Math.min(1, head + 0.001), 'rgba(168,201,255,0)');
      ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.quadraticCurveTo(ctrl.x, ctrl.y, q.x, q.y);
      ctx.strokeStyle = grad; ctx.lineWidth = 1.4; ctx.stroke();
    }
    for (const o of orbits) drawOrbit(o, orbitTime, true);
  }

  function loop(t) {
    raf = 0;
    if (!running) return;
    if (t - last > 30) { frame(t); last = t; } // ~30 fps is plenty for ambient motion
    raf = requestAnimationFrame(loop);
  }
  function update() {
    const should = visible && !document.hidden && !calm;
    if (should && !running) { running = true; raf = requestAnimationFrame(loop); }
    if (!should) { running = false; if (raf) cancelAnimationFrame(raf); raf = 0; }
  }
  resize(); frame(performance.now());
  new ResizeObserver(() => { resize(); frame(performance.now()); }).observe(canvas);
  new IntersectionObserver(entries => { visible = entries[0].isIntersecting; update(); }).observe(canvas);
  document.addEventListener('visibilitychange', update);
  update();
})();
